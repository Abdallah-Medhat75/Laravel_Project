<div>
    <div class="chat-container">
        <div class="chat-list-container">

            @livewire('chat.chat-list')
        </div>
        <div class="chat-box-container">

            @livewire('chat.chatbox')

            @livewire('chat.send-message')
        </div>
    </div>
</div>
