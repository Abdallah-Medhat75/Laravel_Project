<div>
    <div class="chatlist-header">
        <div class="title">
            Chat
        </div>
        <div class="img-container">
            <img src="https://picsum.photos/id/237/200/300" alt="">
        </div>
    </div>
    <div class="chatlist-body">
        @forelse ($conversations as $conversation)
            <div class="chatlist-item" wire:key='{{ $conversation->id }}' wire:click="chatUserSelected({{ $conversation }}, {{ $this->selectUserRelation($conversation)->id }})">
                <div class="chatlist-img-container">
                    <img src='{{ asset("attachements/{$this->selectUserRelation($conversation)->profile}") }}' alt="">
                </div>
                <div class="chatlist-info">
                    <div class="top-row">
                        <div class="list-username">{{ $this->selectUserRelation($conversation)->name }}</div>
                        <span class="date">{{ $conversation->messages->last()->created_at->shortAbsoluteDiffForHumans() }}</span>
                    </div>
                    <div class="bottom-row">
                        <div class="message-body">
                            {{ $conversation->messages->last()->body }}
                        </div>
                        <div class="unread-count">
                            {{ $conversation->messages->where('read', 0)->count() }}
                        </div>
                    </div>
                </div>
            </div>
        @empty
            You Have No Conversations
        @endforelse
    </div>
</div>
