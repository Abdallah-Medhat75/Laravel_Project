<div>
    <ul class="list-group w-75 mx-auto container-fluid">
        @foreach ($users as $user)
            <li class="list-group-item" wire:click='checkConversation({{ $user->id }})'>{{ $user->name }}</li>
        @endforeach
    </ul>
</div>
