<div>
    @if ($selectedConversation)
        <div class="chatbox-header">
            <div class="return">
                <i class="fa-solid fa-arrow-left"></i>
            </div>
            <div class="img-container">
                <img src='{{ asset("attachements/{$receiverInstance->profile}") }}' alt="">
            </div>
            <div class="name">
                {{ $receiverInstance->name }}
            </div>
            <div class="info">
                <div class="info-item">
                    <i class="fa-solid fa-phone"></i>
                </div>
                <div class="info-item">
                    <i class="fa-regular fa-image"></i>
                </div>
                <div class="info-item">
                    <i class="fa-solid fa-circle-info"></i>
                </div>
            </div>
        </div>
        <div class="chatbox-body">
            @foreach ($messages as $message)
                <div class="msg-body {{ $message->receiver_id == auth()->user()->id ? 'me' : 'receiver' }}" wire:key='{{ $message->id }}'>
                    {{ $message->body }}
                    <div class="msg-body-footer">
                        <div class="date">
                            {{ $message->created_at->format('m:i a') }}
                        </div>
                        <div class="read">
                            @if ($message->user->id === auth()->user()->id)
                                @if ($message->read == 0)
                                    <i class="fa-solid fa-check"></i>
                                @else
                                    <i class="fa-solid fa-check-double"></i>
                                @endif
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @else
        <div class="fs-4 text-center text-primary mt-5">
            No Conversation Selected
        </div>
    @endif
    <script src='{{ asset('assets/js/chatbox.js') }}'></script>
</div>
