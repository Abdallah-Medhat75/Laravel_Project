<div>
    <input wire:model.live="search" type="text" placeholder="Search users..."/>

    <ul>
        @foreach($users as $user)
            <li>{{ $user->name }}</li>
        @endforeach
    </ul>
</div>
<script>
    let url = "{{ route('test.route', ['locale' => app()->getLocale()]) }}";

    // Then use 'url' in your AJAX request
    // For example:
    axios.get(url)
        .then(response => {
            console.log(response);
        });
</script>
