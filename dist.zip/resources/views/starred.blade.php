<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Starred Messages') }}
        </h2>
    </x-slot>
    @forelse ($messages as $message)
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900 dark:text-gray-100">
                        {{ $message->body }}
                    </div>
                    <div class="p-6 text-gray-900 dark:text-gray-100">
                        Receiver: {{ $message->receiver->name }}
                    </div>
                    <div class="p-6 text-gray-900 dark:text-gray-100">
                        Sender: {{ $message->sender->name }}
                    </div>
                    <a target="_blank" style="display: block" href="/message/{{ $message->conversation_id }}/#{{ $message->id }}" class="p-6 text-gray-900 bg-white">
                        Want to go to the messsage ? Click Here
                    </a>
                </div>
            </div>
        </div>
    @empty
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900 dark:text-gray-100">
                        No Starred Messages
                    </div>
                </div>
            </div>
        </div>
    @endforelse
</x-app-layout>
