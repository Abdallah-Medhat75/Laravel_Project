<?php

return [
    'process_stored' => 'Process Has Been Added Successfully',
    'process_updated' => 'Process Has Been Updated Successfully',
    'process_destroyed' => 'Process Has Been Destroyed Successfully',
];
