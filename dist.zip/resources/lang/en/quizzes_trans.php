<?php

return [
    'quizzes_stored' => 'Exam Has Been Added Successfully',
    'quizzes_update' => 'Exam Has Been Updated Successfully',
    'quizzes_deleted' => 'Exam Has Been Deleted Successfully',
    'quiz_finsihed' => 'The Exam Has Been Finished Successfully',
    'quiz_aborted' => 'The Exam Has Been Aborted Because You Tried To Bypass The System',
    'quizzes_opened' => 'The Exam Is Available Again',
];
