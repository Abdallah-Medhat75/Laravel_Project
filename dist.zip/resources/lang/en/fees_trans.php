<?php

return [
    'fees_created' => 'Fees Has Been Added Successfully',
    'fees_created' => 'Fees Has Been Updated Successfully',
    'fees_deleted' => 'Fees Has Been Deleted Successfully',
    'fees_added' => 'Student Fees Has Been Added Successfully',
    'fees_invoices_updated' => 'Student Fees Has Been Updated Successfully',
    'fees_invoices_deleted' => 'Student Fees Has Been Deleted Successfully',
];
