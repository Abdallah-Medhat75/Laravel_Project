<?php

return [
    'subject_stored' => 'Subject Has Been Added Successully',
    'subject_updated' => 'Subject Has Been Updated Successully',
    'subject_deleted' => 'Subject Has Been Destroyed Successully',
];
