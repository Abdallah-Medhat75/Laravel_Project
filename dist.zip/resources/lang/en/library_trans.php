<?php

return [
    'library_stored' => 'Exam Has Been Added Successfully',
    'library_update' => 'Exam Has Been Updated Successfully',
    'library_deleted' => 'Exam Has Been Deleted Successfully',
];
