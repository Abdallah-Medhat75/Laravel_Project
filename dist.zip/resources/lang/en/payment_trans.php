<?php

return [
    'payment_stored' => 'Payment Has Been Added Successfully',
    'payment_updated' => 'Payment Has Been Updated Successfully',
    'payment_deleted' => 'Payment Has Been Deleted Successfully',
];
