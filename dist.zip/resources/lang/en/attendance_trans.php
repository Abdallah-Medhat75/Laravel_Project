<?php

return [
    'attendance_stored' => 'Students Attendance Has Been Registered Successfully',
    'attendance_updated' => 'Students Attendance Has Been Updated Successfully',
];
