<?php

return [
    'questions_stored' => 'Question Has Been Added Successfully',
    'questions_updated' => 'Question Has Been Updated Successfully',
    'questions_deleted' => 'Question Has Been Deleted Successfully',
    'questions_warning' => 'Are You Sure You Want To Deleted The Question ?',
];
