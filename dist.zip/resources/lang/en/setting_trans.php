<?php

return [
    'setting_updated' => 'Settings Has Been Updated Successfully',
];
