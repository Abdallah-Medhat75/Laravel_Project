<?php

    return [
        'title_page' => 'Grades Levels',
        'grade_name' => 'Grade Name',
        'add_grade' => 'Add Grade',
        'edit_grade' => 'Edit Grade',
        'delete_grade' => 'Delete Grade',
        'warning_grade' => 'Are you sure you want to delete this grade ?',
        'stage_name_ar' => 'Grade Name In Arabic',
        'stage_name_en' => 'Grade Name In English',
        'notes' => 'Notes',
        'submit' => 'Save Grade',
        'name' => 'Grade Name',
        'processes' => 'Processes',
        'added_successfully' => 'Grade has been added successfully',
        'updated_successfully' => 'Grade has been updated successfully',
        'deleted_successfully' => 'Grade has been deleted successfully',
        'no_notes' => 'No notes available',
        'edit' => 'Edit',
        'close' => 'Close'
    ];
