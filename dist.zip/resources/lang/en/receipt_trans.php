<?php

return [
    'receipt_stored' => 'Receipt Has Been Added Successfully',
    'receipt_updated' => 'Receipt Has Been Updated Successfully',
    'receipt_deleted' => 'Receipt Has Been Deleted Successfully',
];
