<?php

return [
    'Name_Teacher'=>'Name Teacher',
    'Add_Teacher'=>'Add Teacher',
    'Edit_Teacher'=>'Edit Teacher',
    'Delete_Teacher'=>'Delete Teacher',
    'Email'=>'Email',
    'Password'=>'Password',
    'Name_ar'=>'Name_ar',
    'Name_en'=>'Name_en',
    'specialization'=>'specialization',
    'Gender'=>'Gender',
    'Joining_Date'=>'Joining_Date',
    'Address'=>'Address',
    'teachers_added' => 'Teacher Has Been Added Successfully',
    'teachers_edit' => 'Teacher Data Has Been Updated Successfully',
    'teachers_deleted' => 'Teacher Has Been Deleted Successfully',
];
