<?php

return [
    'profile_updated' => 'Profile Has Beed Updated Successfully'
];
