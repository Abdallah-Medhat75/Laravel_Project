<?php

return [
    'attendance_stored' => 'تم تسجيل الحضور بنجاح',
    'attendance_updated' => 'تم تحديث الحضور بنجاح',
];
