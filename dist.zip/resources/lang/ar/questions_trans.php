<?php

return [
    'questions_stored' => 'تم إضافة السؤال بنجاح',
    'questions_updated' => 'تم تعديل السؤال بنجاح',
    'questions_deleted' => 'تم حذف السؤال بنجاح',
    'questions_warning' => 'هل أنت متأكد من حذف السؤال ؟',
];
