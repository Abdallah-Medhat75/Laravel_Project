<?php

return [
    'quizzes_stored' => 'تم إضافة الاختبار بنجاح',
    'quizzes_updated' => 'تم تعديل الاختبار بنجاح',
    'quizzes_deleted' => 'تم حذف الاختبار بنجاح',
    'quiz_finsihed' => 'تم إجراء الاختبار بنجاح',
    'quiz_aborted' => 'تم الخروج من الاختبار لوجود تلاعب بالنظام',
    'quizzes_opened' => 'تم إعادة فتح الاختبار',
];
