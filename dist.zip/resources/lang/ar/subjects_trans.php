<?php

return [
    'subject_stored' => 'تم إضافة المادة بنجاج',
    'subject_updated' => 'تم تعديل المادة بنجاج',
    'subject_deleted' => 'تم حذف المادة بنجاج',
];
