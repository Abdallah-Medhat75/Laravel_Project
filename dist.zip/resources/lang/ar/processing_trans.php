<?php

return [
    'process_stored' => 'تم إضافة العملية بنجاح',
    'process_updated' => 'تم تعديل العملية بنجاح',
    'process_destroyed' => 'تم حذف العملية بنجاح',
];
