<?php

    return [
        'title_page' => 'المراحل الدراسية',
        'grade_name' => 'اسم المرحلة',
        'add_grade' => 'إضافة مرحلة',
        'edit_grade' => 'تعديل مرحلة',
        'delete_grade' => 'حذف مرحلة',
        'warning_grade' => 'هل أنت متأكد من عملية الحذف ؟',
        'stage_name_ar' => 'اسم المرحلة بالعربية',
        'stage_name_en' => 'اسم المرحلة بالإنجليزية',
        'notes' => 'ملاحظات',
        'submit' => 'حفظ البيانات',
        'name' => 'اسم المرحلة',
        'processes' => 'العمليات',
        'added_successfully' => 'تمت إضافة المرحلة بنجاح',
        'updated_successfully' => 'تم تعديل المرحلة بنجاح',
        'deleted_successfully' => 'تم حذف المرحلة بنجاح',
        'no_notes' => 'لا توجد ملاحظة',
        'edit' => 'تعديل',
        'close' => 'إغلاق'
    ];
