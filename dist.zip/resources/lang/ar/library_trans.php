<?php

return [
    'library_stored' => 'تم إضافة الكتاب بنجاح',
    'library_updated' => 'تم تعديل الكتاب بنجاح',
    'library_deleted' => 'تم حذف الكتاب بنجاح',
];
