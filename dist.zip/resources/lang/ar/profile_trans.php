<?php

return [
    'profile_updated' => 'تم تحديث الملف الشخصى بنجاح'
];
