<?php

return [
    'setting_updated' => 'تم تحديث الإعدادات بنجاح',
];
