<?php

return [
    'fees_created' => 'تم إضافة الرسوم بنجاح',
    'fees_updated' => 'تم تحديث الرسوم بنجاح',
    'fees_deleted' => 'تم حذف الرسوم بنجاح',
    'fees_added' => 'تم إضافة رسوم الطالب بنجاج',
    'fees_invoices_updated' => 'تم تعديل رسوم الطالب بنجاح',
    'fees_invoices_deleted' => 'تم حذف رسوم الطالب بنجاح',
];
