<?php

return [
    'receipt_stored' => 'تم إضافة سند القبض بنجاح',
    'receipt_updated' => 'تم تعديل سند القبض بنجاح',
    'receipt_deleted' => 'تم حذف سند القبض بنجاح',
];
