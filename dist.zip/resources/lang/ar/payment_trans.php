<?php

return [
    'payment_stored' => 'تم إضافة الدفع بنجاح',
    'payment_updated' => 'تم تعديل الدفع بنجاح',
    'payment_deleted' => 'تم حذف الدفع بنجاح',
];
