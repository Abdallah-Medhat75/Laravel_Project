import './bootstrap';

// Start Global Variables
let userId = document.body.dataset.userId;
// End Global Variables

window.Echo.private(`users.${userId}`).listen('.the-event', data => {
    fetch(`https://advanced-chat.test/resting/conversations/message/${data.sender_id}/${data.message_id}`)
        .then(response => response.json())
        .then(info => {
            function doNotify() {
                let title = info.sender_name;
                let options = {
                    body: info.message_body,
                    icon: info.sender_profile ? `${document.body.dataset.assetUrl}/${info.sender_profile}` : info.sender_placeholder,
                }
                let notify = new Notification(title, options);
                notify.onshow = event => {
                    console.log('SHOW', event.currentTarget.data);
                };
                notify.onclose = event => {
                    console.log('CLOSE', event.currentTarget.body);
                };
                notify.onclick = event => {
                    window.open(`https://advanced-chat.test/message/${data.conversation_id}/#${data.message_id}`, '_blank');
                }
                setTimeout(notify.close.bind(notify), 5000); // Close The Notification After 5 Seconds
            }
            if ('Notification' in window) {
                // console.log(Notification.permission); for bebugging if you want
                if (Notification.permission === 'granted') {
                    // If it's okay, let's create a notification
                    doNotify();
                } else {
                    // Notification is denied
                    Notification.requestPermission()
                        .then(result => {
                            console.log(result);
                            if (Notification.permission === 'granted') {
                                doNotify();
                            }
                        }).catch(err => {
                            console.log(err);
                        });
                }
            }
        })
        .catch(err => console.log(err));
});
