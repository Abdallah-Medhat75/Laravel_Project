<?php

namespace App\Notifications;

use App\Models\Invoices;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class NewInvoice extends Notification
{
    use Queueable;
    private $latest;

    /**
     * Create a new notification instance.
     */
    public function __construct(Invoices $latest)
    {
        $this->latest = $latest;
    }
    public function via(object $notifiable): array
    {
        return ['database'];
    }
    public function toDatabase(object $notifiable): array {
        return [
            // 'data' => $this->details['body']
            'id' => $this->latest->id,
            'title' => 'تم إضافة فاتورة جديدة بواسطة',
            'user' => auth()->user()->name,
        ];
    }
}
