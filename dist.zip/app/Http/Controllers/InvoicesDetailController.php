<?php

namespace App\Http\Controllers;

use App\Models\Invoice_attachment;
use App\Models\Invoices_detail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class InvoicesDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Invoices_detail $invoices_detail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Invoices_detail $invoices_detail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Invoices_detail $invoices_detail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {
        $invoices = Invoice_attachment::findOrFail($request->id_file);
        // To Remove The File
        Storage::disk('files')->delete($request->invoice_number . '/' . $request->file_name);
        // To Remove The Whole Directory
        // Storage::disk('files')->deleteDirectory($request->invoice_number);
        $invoices->delete();
        session()->flash('delete', 'تم حذف المرفق بنجاح');
        return back();
    }
}
