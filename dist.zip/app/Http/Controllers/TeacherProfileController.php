<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Repository\TeacherProfileRepositoryInterface;

class TeacherProfileController extends Controller
{
    public function __construct(private TeacherProfileRepositoryInterface $teacher_profile) {}
    public function index() {
        return $this->teacher_profile->index();
    }
    public function update(Request $request, $id) {
        return $this->teacher_profile->update($request, $id);
    }
}
