<?php

namespace App\Http\Controllers;

use App\Mail\TestEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class MailController extends Controller
{
    public function send(): string {
        Mail::to('mjdajarsww@gmail.com')->send(new TestEmail());

        return "Sended";
    }
}
