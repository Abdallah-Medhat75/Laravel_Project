<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Repository\StudentProfileRepositoryInterface;

class StudentProfileController extends Controller
{
    public function __construct(private StudentProfileRepositoryInterface $student_profile) {}
    public function index()
    {
        return $this->student_profile->index();
    }
    public function update(Request $request, string $id)
    {
        return $this->student_profile->update($request, $id);
    }
}
