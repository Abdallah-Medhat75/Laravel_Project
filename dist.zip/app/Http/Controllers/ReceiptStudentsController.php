<?php

namespace App\Http\Controllers;

use App\Models\ReceiptStudents;
use Illuminate\Http\Request;
use App\Repository\ReceiptStudentsRepositoryInterface;

class ReceiptStudentsController extends Controller
{
    public function __construct(private ReceiptStudentsRepositoryInterface $receipt) {}
    public function index()
    {
        return $this->receipt->index();
    }
    public function create()
    {
        //
    }
    public function store(Request $request)
    {
        return $this->receipt->store($request);
    }
    public function show($id)
    {
        return $this->receipt->show($id);
    }
    public function edit($id)
    {
        return $this->receipt->edit($id);
    }
    public function update(Request $request)
    {
        return $this->receipt->update($request);
    }
    public function destroy(Request $request)
    {
        return $this->receipt->destroy($request);
    }
}
