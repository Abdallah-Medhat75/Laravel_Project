<?php

namespace App\Http\Controllers;

use App\Models\Question;
use Illuminate\Http\Request;
use App\Repository\QuestionRepositoryInterface;

class QuestionController extends Controller
{
    public function __construct(private QuestionRepositoryInterface $question) {}
    public function index()
    {
        return $this->question->index();
    }
    public function create()
    {
        return $this->question->create();
    }
    public function store(Request $request)
    {
        return $this->question->store($request);
    }
    public function edit($id)
    {
        return $this->question->edit($id);
    }
    public function update(Request $request)
    {
        return $this->question->update($request);
    }
    public function destroy(Request $request)
    {
        return $this->question->destroy($request);
    }
}
