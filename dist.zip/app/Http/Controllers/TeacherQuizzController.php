<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repository\TeacherQuizzRepositoryInterface;

class TeacherQuizzController extends Controller
{
    public function __construct(private TeacherQuizzRepositoryInterface $teacher_quiz) {}
    public function index()
    {
        return $this->teacher_quiz->index();
    }
    public function create()
    {
        return $this->teacher_quiz->create();
    }
    public function store(Request $request)
    {
        return $this->teacher_quiz->store($request);
    }
    public function show(string $id) {
        return $this->teacher_quiz->show($id);
    }
    public function edit(string $id)
    {
        return $this->teacher_quiz->edit($id);
    }
    public function update(Request $request)
    {
        return $this->teacher_quiz->update($request);
    }
    public function destroy(string $id)
    {
        return $this->teacher_quiz->destroy($id);
    }
    public function getClassrooms($id) {
        return $this->teacher_quiz->getClassrooms($id);
    }
    public function Get_Sections($id) {
        return $this->teacher_quiz->Get_Sections($id);
    }
    public function student_quizze($quizze_id) {
        return $this->teacher_quiz->student_quizze($quizze_id);
    }
    public function repeat_quizze(Request $request) {
        return $this->teacher_quiz->repeat_quizze($request);
    }
}
