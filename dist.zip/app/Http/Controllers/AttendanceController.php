<?php

namespace App\Http\Controllers;

use App\Models\Attendance;
use Illuminate\Http\Request;
use App\Repository\AttendanceRepositoryInterface;

class AttendanceController extends Controller
{
    public function __construct(private AttendanceRepositoryInterface $attendance) {}
    public function index()
    {
        return $this->attendance->index();
    }
    public function store(Request $request)
    {
        return $this->attendance->store($request);
    }
    public function show($id)
    {
        return $this->attendance->show($id);
    }
    public function update(Request $request)
    {
        return $this->attendance->update($request);
    }
    public function destroy(Request $request)
    {
        return $this->attendance->destroy($request);
    }
}
