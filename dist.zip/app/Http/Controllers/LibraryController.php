<?php

namespace App\Http\Controllers;

use App\Models\Library;
use Illuminate\Http\Request;
use App\Repository\LibraryRepositoryInterface;

class LibraryController extends Controller
{
    public function __construct(private LibraryRepositoryInterface $library) {}
    public function index()
    {
        return $this->library->index();
    }
    public function create()
    {
        return $this->library->create();
    }
    public function edit($id)
    {
        return $this->library->edit($id);
    }
    public function store(Request $request)
    {
        return $this->library->store($request);
    }
    public function update(Request $request, Library $library)
    {
        return $this->library->update($request);
    }
    public function destroy(Request $request)
    {
        return $this->library->destroy($request);
    }
    public function download($filename) {
        return $this->library->download($filename);
    }
}
