<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Repository\TeacherQuestionRepositoryInterface;

class TeacherQuestionController extends Controller
{
    public function __construct(private TeacherQuestionRepositoryInterface $teacher_question) {}
    public function store(Request $request)
    {
        return $this->teacher_question->store($request);
    }
    public function create(string $id)
    {
        return $this->teacher_question->create($id);
    }
    public function edit(string $id)
    {
        return $this->teacher_question->edit($id);
    }
    public function update(Request $request, string $id)
    {
        return $this->teacher_question->update($request, $id);
    }
    public function destroy(string $id)
    {
        return $this->teacher_question->destroy($id);
    }
}
