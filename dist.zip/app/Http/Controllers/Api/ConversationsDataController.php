<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class ConversationsDataController extends Controller
{
    public function index($auth_id, $search) {
        $searchedUsersId = User::where('name', $search)->value('id');
        $searchedConversation = Conversation::where('receiver_id', $searchedUsersId)->where('sender_id', $auth_id)->orWhere('sender_id', $searchedUsersId)->where('receiver_id', $auth_id)->get();
        if (empty($searchedConversation->first())) {
            return response([], 200);
        }
        $body = [
            $searchedConversation->first()
        ];
        return response($body, 200);
    }
    public function retrieve($sender_id, $message_id) {
        $editedId = $sender_id + 2;
        $sender_name = User::where('id', $sender_id)->value('name');
        $sender_profile = User::where('id', $sender_id)->value('profile');
        $sender_placholder = Http::get("https://api.unsplash.com/search/photos?query=face-{$editedId}&client_id=HEFka9TkOOBxRLbyv-wMK0hJkCNfxsG1MB_mhf8psX4&per_page=1&page=1")->json()['results'][0]['user']['profile_image']['medium'];
        $message_body = Message::where('id', $message_id)->value('id');
        $body = [
            'sender_name' => $sender_name,
            'message_body' => $message_body,
            'sender_profile' => $sender_profile,
            'sender_placeholder' => $sender_placholder
        ];
        return response($body, 200);
    }
}
