<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ConversationsDataController extends Controller
{
    public function index($auth_id, $search) {
        $searchedUsersId = User::where('name', $search)->value('id');
        $searchedConversation = Conversation::where('receiver_id', $searchedUsersId)->where('sender_id', $auth_id)->orWhere('sender_id', $searchedUsersId)->where('receiver_id', $auth_id)->get();
        $body = [
            // 'user_id' => $auth_id,
            'conversation' => $searchedConversation
        ];
        return response($body, 200);
    }
}
