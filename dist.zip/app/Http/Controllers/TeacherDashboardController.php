<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repository\TeacherDashboardRepositoryInterface;

class TeacherDashboardController extends Controller
{
    public function __construct(private TeacherDashboardRepositoryInterface $teacher_dashboard) {}
    public function index()
    {
        return $this->teacher_dashboard->index();
    }
    public function sections() {
        return $this->teacher_dashboard->sections();
    }
    public function attendance(Request $request) {
        return $this->teacher_dashboard->attendance($request);
    }
    public function attendanceReport() {
        return $this->teacher_dashboard->attendanceReport();
    }
    public function attendanceSearch(Request $request) {
        return $this->teacher_dashboard->attendanceSearch($request);
    }
}
