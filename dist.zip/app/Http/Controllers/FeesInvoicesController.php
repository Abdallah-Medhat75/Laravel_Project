<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repository\FeeInvoicesRepositoryInterface;

class FeesInvoicesController extends Controller
{

    public function __construct(private FeeInvoicesRepositoryInterface $fees_invoices) {}
    public function index()
    {
        return $this->fees_invoices->index();
    }
    public function store(Request $request)
    {
        return $this->fees_invoices->store($request);
    }
    public function show($id)
    {
        return $this->fees_invoices->show($id);
    }
    public function edit($id)
    {
        return $this->fees_invoices->edit($id);
    }
    public function update(Request $request)
    {
        return $this->fees_invoices->update($request);
    }
    public function destroy(Request $request)
    {
        return $this->fees_invoices->destroy($request);
    }
}
