<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreGrades;
use App\Models\Grade;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class GradeController extends Controller
{

  /**
   * Display a listing of the resource.
   *
   * @return Response
   */
  public function index()
  {
      $grades = Grade::all();
      return view('pages.grades.grades', compact('grades'));
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return Response
   */
  public function create()
  {

  }

  /**
   * Store a newly created resource in storage.
   *
   * @return Response
   */
  public function store(StoreGrades $request)
  {
      $validated = $request->validated();
      $grade = new Grade();
      $grade->Name = ['en' => $request->Name_en, 'ar' => $request->Name];
      $grade->Notes = $request->Notes;
      $grade->save();
      session()->flash('grade_added', trans('grades_trans.added_successfully'));
      return back();
  }

  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function show($id)
  {

  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return Response
   */
  public function edit($id)
  {

  }

  /**
   * Update the specified resource in storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function update(StoreGrades $request)
  {
      $request->validated();
      $grade = Grade::find($request->id);
      $grade->update([
          $grade->Name = ['ar' => $request->Name, 'en' => $request->Name_en],
          $grade->Notes = $request->Notes,
      ]);
      session()->flash('grade_updated', trans('grades_trans.updated_successfully'));
      return back();
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return Response
   */
  public function destroy(Request $request)
  {
      Grade::find($request->id)->delete();
      session()->flash('deleted_successfully', trans('grades_trans.deleted_successfully'));
      return back();
  }

}

?>
