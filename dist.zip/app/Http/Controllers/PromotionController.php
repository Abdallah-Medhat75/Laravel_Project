<?php

namespace App\Http\Controllers;

use App\Repository\StudentPromotionRepositoryInterface;
use Illuminate\Http\Request;

class PromotionController extends Controller
{
    public function __construct(private StudentPromotionRepositoryInterface $promotion) {}
    public function index()
    {
        return $this->promotion->index();
    }

    public function create()
    {
        return $this->promotion->create();
    }

    public function store(Request $request)
    {
        return $this->promotion->store($request);
    }

    public function show(string $id)
    {
        //
    }

    public function edit(string $id)
    {
        //
    }

    public function update(Request $request, string $id)
    {
        //
    }

    public function destroy(Request $request)
    {
        return $this->promotion->destroy($request);
    }
}
