<?php

namespace App\Http\Controllers;

use App\Models\Subject;
use Illuminate\Http\Request;
use App\Repository\SubjectRepositoryInterface;

class SubjectController extends Controller
{
    public function __construct(private SubjectRepositoryInterface $subject) {}
    public function index()
    {
        return $this->subject->index();
    }
    public function create()
    {
        return $this->subject->create();
    }
    public function store(Request $request)
    {
        return $this->subject->store($request);
    }
    public function edit($id)
    {
        return $this->subject->edit($id);
    }
    public function update(Request $request, Subject $subject)
    {
        return $this->subject->update($request);
    }
    public function destroy(Request $request)
    {
        return $this->subject->destroy($request);
    }
}
