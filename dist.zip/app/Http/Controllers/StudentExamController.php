<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Repository\StudentExamRepositoryInterface;

class StudentExamController extends Controller
{
    public function __construct(private StudentExamRepositoryInterface $student_exam) {}
    public function index()
    {
        return $this->student_exam->index();
    }
    public function show(string $id)
    {
        return $this->student_exam->show($id);
    }
}
