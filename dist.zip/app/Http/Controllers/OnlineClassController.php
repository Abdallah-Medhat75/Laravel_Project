<?php

namespace App\Http\Controllers;

use App\Models\OnlineClass;
use Illuminate\Http\Request;
use App\Repository\OnlineClassesRepositoryInterface;

class OnlineClassController extends Controller
{
    public function __construct(private OnlineClassesRepositoryInterface $online_class) {}
    public function index()
    {
        return $this->online_class->index();
    }
    public function create()
    {
        return $this->online_class->create();
    }
    public function store(Request $request)
    {
        return $this->online_class->store($request);
    }
    public function destroy(Request $request)
    {
        return $this->online_class->destroy($request);
    }
}
