<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Http\Requests\StoreStudentsRequest;
use App\Repository\StudentsRepositoryInterface;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    protected $student;
    public function __construct(StudentsRepositoryInterface $student) {
        $this->student = $student;
    }

    public function index()
    {
        return $this->student->showStudents();
    }

    public function create()
    {
        return $this->student->createStudents();
    }

    public function store(StoreStudentsRequest $request)
    {
        return $this->student->Store_Student($request);
    }

    public function show($id)
    {
        return $this->student->showAttachments($id);
    }

    public function edit(string $id)
    {
        return $this->student->editStudent($id);
    }

    public function update(StoreStudentsRequest $request)
    {
        return $this->student->updateStudent($request);
    }

    public function destroy(Request $request)
    {
        return $this->student->deleteStudent($request);
    }

    public function Get_classrooms($id)
    {
        return $this->student->Get_classrooms($id);
    }
    public function Get_Sections($id)
    {
        return $this->student->Get_Sections($id);
    }
    public function Upload_attachment(Request $request)
    {
        return $this->student->Upload_attachment($request);
    }

    public function Download_attachment($studentsname, $filename)
    {
        return $this->student->Download_attachment($studentsname, $filename);
    }

    public function Delete_attachment(Request $request)
    {
        return $this->student->Delete_attachment($request);

    }
}
