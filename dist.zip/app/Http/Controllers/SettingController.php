<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;
use App\Repository\SettingRepositoryInterface;

class SettingController extends Controller
{
    public function __construct(private SettingRepositoryInterface $setting) {}
    public function index() {
        return $this->setting->index();
    }
    public function update(Request $request) {
        return $this->setting->update($request);
    }
}
