<?php

namespace App\Http\Controllers;

use App\Models\Classroom;
use App\Models\Grade;
use Illuminate\Http\Request;

class ClassroomController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $My_Classes = Classroom::all();
        $Grades = Grade::all();
        return view('pages.my_classes.my_classes', compact('My_Classes', 'Grades'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
//        $request->validate([
//            'Name' => 'required',
//            'Name_class_en' => 'required',
//        ],
//        [
//            'Name.required' => trans('validation.required'),
//            'Name_class_en.required' => trans('validation.required'),
//        ]);
        $List_Classes = $request->List_Classes;
        foreach ($List_Classes as $List_Class) {
            Classroom::create([
                'Name_Class' => ['en' => $List_Class['Name_class_en'], 'ar' => $List_Class['Name']],
                'Grade_id' => $List_Class['Grade_id'],
            ]);
        }
        session()->flash('class_added', trans('My_Classes_trans.added_successfully'));
        return back();
    }

    /**
     * Display the specified resource.
     */
    public function show(Classroom $classroom)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Classroom $classroom)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        $classes = Classroom::find($request->id);
        $classes->update([
            'Name_Class' => ['en' => $request->Name_en, 'ar' => $request->Name],
            'Grade_id' => $request->Grade_id,
        ]);
        session()->flash('class_updated', trans('My_Classes_trans.updated_successfully'));
        return back();
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {
        Classroom::find($request->id)->delete();
        session()->flash('class_deleted', trans('My_Classes_trans.class_deleted'));
        return back();
    }
}
