<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Message;

class StarredController extends Controller
{
    public function index() {
        $messages = Message::where('starred', 1)->get();
        return view('starred', compact('messages'));
    }
    public function starring($message_id) {
        Message::findOrFail($message_id)->update(['starred' => 1]);
        return back();
    }
}
