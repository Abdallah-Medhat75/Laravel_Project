<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Repository\ChildrenRepositoryInterface;

class ChildrenController extends Controller
{
    public function __construct(private ChildrenRepositoryInterface $children) {}
    public function index()
    {
        return $this->children->index();
    }
    public function results($id) {
        return $this->children->results($id);
    }
    public function attendances() {
        return $this->children->attendances();
    }
    public function attendanceSearch(Request $request) {
        return $this->children->attendanceSearch($request);
    }
    public function fees() {
        return $this->children->fees();
    }
    public function receiptStudent(string $id) {
        return $this->children->receiptStudent($id);
    }
    public function profile() {
        return $this->children->profile();
    }
    public function update(Request $request, string $id) {
        return $this->children->update($request, $id);
    }
}
