<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;
use App\Models\Teacher;

class Gender extends Model
{
    use HasTranslations;
    public $translatable = ['Name'];
    protected $table = 'genders';
    protected $guarded = [];
}
