<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ParentAttachments extends Model
{
    protected $table = 'parent_attachments';
    protected $guarded = [];
}
