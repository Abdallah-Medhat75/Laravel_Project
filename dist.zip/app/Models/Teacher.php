<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;
use App\Models\Gender;
use App\Models\Specialization;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Models\Section;
use Illuminate\Auth\Middleware\Authenticate;

class Teacher extends Authenticatable
{
    use HasTranslations;
    public $translatable = ['Name'];
    protected $table = 'teachers';
    protected $guarded = [];

    public function genders() {
        return $this->belongsTo(Gender::class, 'Gender_id');
    }
    public function specializations() {
        return $this->belongsTo(Specialization::class, 'Specialization_id');
    }
    public function Sections() {
        return $this->belongsToMany(Section::class, 'teacher_section');
    }
}
