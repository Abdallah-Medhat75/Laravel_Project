<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Auth;

class Conversation extends Model
{
    use SoftDeletes;
    protected $guarded = ['placeholder'];

    public function messages() {
        return $this->hasMany(Message::class);
    }
    public function getReceiver() {
        return $this->receiver_id != Auth::id() ? User::findOrFail($this->receiver_id) : User::findOrFail($this->sender_id);
    }
    public function getSender() {
        return $this->receiver_id != Auth::id() ? User::findOrFail($this->sender_id) : User::findOrFail($this->receiver_id);
    }
    public function isLastMessageRead() {
        $user = Auth::user();
        $lastMessage = $this->messages->last();
        // Also Works, but notice messages is written as a function not a property
        // $lastMessage = $this->messages()->latest()->first();
        if ($lastMessage) {
            return $lastMessage->read_at !== NULL && $lastMessage->sender_id == $user->id;
        }
    }
}
