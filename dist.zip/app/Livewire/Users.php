<?php

namespace App\Livewire;

use App\Models\Conversation;
use App\Models\User;
use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class Users extends Component
{
    public $users;
    public function mount() {
        $this->users = User::where('id', '!=', Auth::id())->get();
        foreach ($this->users as &$user) {
            $editedId = $user->id + 2;
            $placeholder = Http::get("https://api.unsplash.com/search/photos?query=face-{$editedId}&client_id=HEFka9TkOOBxRLbyv-wMK0hJkCNfxsG1MB_mhf8psX4&per_page=1&page=1")->json()['results'][0]['user']['profile_image']['medium'];
            $user->placeholder = $placeholder;
        }
        unset($user);
    }
    public function message($id) {
        $auth_id = Auth::id();
        $existingConversation = Conversation::where(function ($query) use($auth_id, $id) {
            $query->where('sender_id', $auth_id)->where('receiver_id', $id);
        })->orWhere(function ($query) use($auth_id, $id) {
            $query->where('sender_id', $id)->where('receiver_id', $auth_id);
        })->first();
        if ($existingConversation) {
            return redirect()->route('message', ['query' => $existingConversation->id]);
        }
        $createdConversation = Conversation::create([
            'sender_id' => $auth_id,
            'receiver_id' => $id
        ]);
        return redirect()->route('message', ['query' => $createdConversation->id]);
    }
    public function render()
    {
        return view('livewire.users');
    }
}
