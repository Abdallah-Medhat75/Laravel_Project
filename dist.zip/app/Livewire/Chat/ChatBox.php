<?php

namespace App\Livewire\Chat;

use App\Events\MessageRead;
use App\Events\MessageSent;
use App\Models\Message;
// use App\Notifications\MessageSent;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Livewire\Component;

class ChatBox extends Component
{
    public $selectedConversation, $body, $loadedMessages, $paginate = 10;
    protected function getListeners(): array
    {
        $auth_id = Auth::id();
        return [
            'loadMore',
            "echo-private:users.{$auth_id},MessageSent" => 'broadcastedNotifications',
            "echo-private:users.{$auth_id},MessageRead" => 'broadcastedRead',
            'refresh' => '$refresh'
        ];
    }
    public function broadcastedNotifications($event) {
        // dd($event);
        if ($event['conversation_id'] == $this->selectedConversation->id) {
            $this->dispatch('scroll-bottom');
            $newMessage = Message::findOrFail($event['message_id']);
            $this->getPicture();
            $this->loadedMessages->push($newMessage);
            $newMessage->read_at = now();
            $newMessage->save();
        }
    }
    public function broadcastedRead($event) {
        $this->dispatch('refresh');
    }
    public function getPicture() {
        $editedId = $this->selectedConversation->getReceiver()->id + 2;
        $placeholder = Http::get("https://api.unsplash.com/search/photos?query=face-{$editedId}&client_id=HEFka9TkOOBxRLbyv-wMK0hJkCNfxsG1MB_mhf8psX4&per_page=1&page=1")->json()['results'][0]['user']['profile_image']['medium'];
        $this->selectedConversation->placeholder = $placeholder;
    }
    public function mount() {
        $this->getPicture();
        $this->loadMessages();
    }
    public function loadMore() {
        $this->paginate += 10;
        $this->getPicture();
        $this->loadMessages();
        $this->dispatch('update-chat-height');
    }
    public function loadMessages() {
        $count = Message::where('conversation_id', $this->selectedConversation->id)->count();
        $this->loadedMessages = Message::where('conversation_id', $this->selectedConversation->id)->skip($count - $this->paginate)->take($this->paginate)->get();
        return $this->loadedMessages;
    }
    public function sendMessage() {
        $this->validate(['body' => 'required']);
        $createdMessage = Message::create([
            'conversation_id' => $this->selectedConversation->id,
            'sender_id' => Auth::id(),
            'receiver_id' => $this->selectedConversation->getReceiver()->id,
            'body' => $this->body,
        ]);
        $this->reset('body');
        $this->dispatch('scroll-bottom');
        $this->loadedMessages->push($createdMessage);
        unset($this->selectedConversation->placeholder);
        $this->selectedConversation->update([
            'updated_at' => now()
        ]);
        // $this->getPicture();
        $this->dispatch('refresh')->to('chat.chat-list');
        broadcast(new MessageSent($this->selectedConversation, $createdMessage, $this->selectedConversation->getReceiver()->id));
    }
    public function render()
    {
        $this->getPicture();
        return view('livewire.chat.chat-box');
    }
}
