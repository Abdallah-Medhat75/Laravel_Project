<?php

namespace App\Livewire\Chat;

use App\Models\User;
use Livewire\Component;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class ChatList extends Component
{
    public $selectedConversation, $conversations, $query, $search;
    protected function getListeners(): array
    {
        return [
            'refresh' => '$refresh',
        ];
    }
    public function getPicture() {
        $user = Auth::user();
        $this->conversations = $user->sentConversations()->latest('updated_at')->get()->merge($user->receivedConversations()->latest('updated_at')->get());
        foreach ($this->conversations as &$conversation) {
            $editedId = $conversation->getReceiver()->id + 2;
            $placeholder = Http::get("https://api.unsplash.com/search/photos?query=face-{$editedId}&client_id=HEFka9TkOOBxRLbyv-wMK0hJkCNfxsG1MB_mhf8psX4&per_page=1&page=1")->json()['results'][0]['user']['profile_image']['medium'];
            $conversation->placeholder = $placeholder;
        }
        unset($conversation);
    }
    public function SearchConversations() {
        $auth_id = Auth::id();
        dd($this->search);
        $searchedConversation = Http::get(url("api/conversations/$auth_id/{$this->search}"))->json();
        dd($searchedConversation);
        // $this->conversations = $searchedConversation;
    }
    public function render()
    {
        $this->getPicture();
        return view('livewire.chat.chat-list');
    }
}
