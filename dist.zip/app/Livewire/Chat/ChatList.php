<?php

namespace App\Livewire\Chat;

use App\Models\Conversation;
use App\Models\User;
use Livewire\Component;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class ChatList extends Component
{
    public $selectedConversation, $conversations, $query, $search;
    protected function getListeners(): array
    {
        return [
            'refresh' => '$refresh',
        ];
    }
    public function getPicture() {
        foreach ($this->conversations as &$conversation) {
            $editedId = $conversation->getReceiver()->id + 2;
            $placeholder = Http::get("https://api.unsplash.com/search/photos?query=face-{$editedId}&client_id=HEFka9TkOOBxRLbyv-wMK0hJkCNfxsG1MB_mhf8psX4&per_page=1&page=1")->json()['results'][0]['user']['profile_image']['medium'];
            $conversation->placeholder = $placeholder;
        }
        unset($conversation);
    }
    public function mount() {
        $user = Auth::user();
        $this->conversations = $user->sentConversations()->latest('updated_at')->get()->merge($user->receivedConversations()->latest('updated_at')->get());
        $this->getPicture();
    }
    public function SearchConversations() {
        $auth_id = Auth::id();
        // Don't Do it in the 127.0.0.1:8000 that runs locally because it has problems with APIs
        // $searchedConversation = Http::get("http://localhost/advanced-chat/public/api/conversations/$auth_id/{$this->search}")->json();
        $searchedUsersId = User::where('name', $this->search)->value('id');
        $searchedConversation = Conversation::where('receiver_id', $searchedUsersId)->where('sender_id', $auth_id)->orWhere('sender_id', $searchedUsersId)->where('receiver_id', $auth_id)->get();
        // dd($searchedConversation);
        $this->conversations = $searchedConversation;
        // $this->dispatch('refresh')->self();
    }
    public function render()
    {
        $this->getPicture();
        return view('livewire.chat.chat-list');
    }
}
