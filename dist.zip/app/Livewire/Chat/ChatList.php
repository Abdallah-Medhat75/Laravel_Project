<?php

namespace App\Livewire\Chat;

use App\Models\User;
use App\Models\Conversation;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Auth as FacadesAuth;
use Livewire\Component;

class ChatList extends Component
{
    public $auth_id, $conversations, $selectedConversation;
    protected function getListeners(): array
    {
        return [
            'chatUserSelected',
            'refresh' => '$refresh'
        ];
    }
    public function mount() {
        $this->auth_id = Auth::user()->id;
        $this->conversations = Conversation::where('sender_id', $this->auth_id)->orWhere('receiver_id', $this->auth_id)->orderBy('last_time_message', 'ASC')->get();
    }
    public function selectUserRelation($conversation) {
        return $conversation->receiver->id == Auth::user()->id ? $conversation->sender : $conversation->receiver;
    }
    public function chatUserSelected(Conversation $conversation, $receiverId) {
        $this->selectedConversation = $conversation;
        $receiverInstance = User::findOrFail($receiverId);
        $this->dispatch('loadConversation', $this->selectedConversation, $receiverInstance)->to('chat.chatbox');
        $this->dispatch('updateSendMessage', $this->selectedConversation, $receiverInstance)->to('chat.send-message');
    }
    public function refresh() {

    }
    public function render() {
        return view('livewire.chat.chat-list');
    }
}
