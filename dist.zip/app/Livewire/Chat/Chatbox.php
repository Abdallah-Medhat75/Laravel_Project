<?php

namespace App\Livewire\Chat;

use App\Events\MessageSent;
use App\Events\MessageRead;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\User;
use Livewire\Component;

use Illuminate\Support\Facades\Auth;

class Chatbox extends Component
{
    public $selectedConversation, $receiverInstance, $messages, $messages_count, $paginate = 10;
    protected function getListeners(): array
    {
        $auth_id = Auth::user()->id;
        return [
            "echo-private:chat.{$auth_id},MessageSent" => 'broadcastedMessageReceived',
            "echo-private:chat.{$auth_id},MessageRead" => 'broadcastedMessageRead',
            'loadConversation',
            'pushMessage',
            'loadMore',
            'MessageReadBroadcaster'
        ];
    }
    public function broadcastedMessageReceived($event) {
        $this->dispatch('refresh')->to('chat.chat-list');
        $broadcastedMessage = Message::find($event['message_id']);
        if ($this->selectedConversation) {
            if ((int) $this->selectedConversation->id === (int) $event['conversation_id']) {
                $broadcastedMessage->read = 1;
                $broadcastedMessage->save();
                $this->pushMessage($broadcastedMessage->id);
                $this->dispatch('MessageReadBroadcaster')->self();
            }
        }
    }
    public function loadConversation(Conversation $conversation, User $receiver) {
        $this->selectedConversation = $conversation;
        $this->receiverInstance = $receiver;
        $this->messages_count = Message::where('conversation_id', $this->selectedConversation->id)->count();
        $this->messages = Message::where('conversation_id', $this->selectedConversation->id)->skip($this->messages_count - $this->paginate)->take($this->paginate)->get();
        $this->dispatch('chatSelected');
        Message::where('conversation_id', $this->selectedConversation->id)->where('receiver_id', Auth::user()->id)->update(['read' => 1]);
        $this->dispatch('MessageReadBroadcaster')->self();
    }
    public function broadcastedMessageRead($event) {
        if ($this->selectedConversation) {
            if ((int) $this->selectedConversation->id === (int) $event['conversation_id']) {
                $this->dispatch('markMessageAsRead');
            }
        }
    }
    public function MessageReadBroadcaster() {
        broadcast(new MessageRead($this->selectedConversation->id, $this->receiverInstance->id));
    }
    public function pushMessage($messageId) {
        $newMessage = Message::findOrFail($messageId);
        $this->messages->push($newMessage);
        $this->dispatch('rowChatToBottom');
    }
    public function loadMore() {
        $this->paginate += 10;
        $this->messages_count = Message::where('conversation_id', $this->selectedConversation->id)->count();
        $this->messages = Message::where('conversation_id', $this->selectedConversation->id)->skip($this->messages_count - $this->paginate)->take($this->paginate)->get();
    }
    public function render()
    {
        return view('livewire.chat.chatbox');
    }
}
