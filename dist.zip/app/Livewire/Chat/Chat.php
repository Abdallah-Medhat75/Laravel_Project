<?php

namespace App\Livewire\Chat;

use App\Models\Conversation;
use Livewire\Component;

use App\Models\Message;
use Illuminate\Support\Facades\Auth;

class Chat extends Component
{
    public $query, $selectedConversation;
    public function mount() {
        $this->selectedConversation = Conversation::findOrFail($this->query);
        Message::where('conversation_id', $this->selectedConversation->id)->where('receiver_id', Auth::id())->whereNull('read_at')->update(['read_at' => now()]);
    }
    public function render()
    {
        return view('livewire.chat.chat');
    }
}
