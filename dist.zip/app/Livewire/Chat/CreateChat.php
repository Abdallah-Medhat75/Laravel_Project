<?php

namespace App\Livewire\Chat;

use App\Models\Conversation;
use App\Models\Message;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class CreateChat extends Component
{
    public $users;
    public $message = 'Hello how are you';
    public function checkConversation($senderId) {
        $checkedConversation = Conversation::where('receiver_id', Auth::user()->id)->where('sender_id', $senderId)->orWhere('receiver_id', $senderId)->where('sender_id', Auth::user()->id)->get();
        if ($checkedConversation->count() == 0) {
            $createdConversation = Conversation::create([
                'receiver_id' => Auth::user()->id,
                'sender_id' => $senderId
            ]);
            $createdMessage = Message::create([
                'conversation_id' => $createdConversation->id,
                'sender_id' => $senderId,
                'receiver_id' => Auth::user()->id,
                'body' => $this->message
            ]);
            $createdConversation->update([
                'last_time_message' => $createdMessage->created_at
            ]);
            dd("Saved the message: $createdMessage");
        } else if ($checkedConversation->count() >= 1) {
            dd('Conversation Exists');
        }
    }
    public function render()
    {
        $this->users = User::where('id', '!=', Auth::user()->id)->get();
        return view('livewire.chat.create-chat');
    }
}
