<?php

namespace App\Livewire\Chat;

use App\Events\MessageSent;
use Livewire\Component;

use App\Models\User;
use App\Models\Message;
use App\Models\Conversation;
use Illuminate\Support\Facades\Auth;

class SendMessage extends Component
{
    public $selectedConversation, $receiverInstance, $body, $sender_id, $receiver_id, $createdMessage;
    protected function getListeners(): array {
        return [
            'updateSendMessage' => 'updateSendMessage',
            'dispatchMessageSent'
        ];
    }
    public function updateSendMessage(Conversation $conversation, User $receiver) {
        $this->selectedConversation = $conversation;
        $this->receiverInstance = $receiver;
    }
    public function sendMessage() {
        $this->sender_id = $this->selectedConversation->sender_id == Auth::user()->id ? $this->selectedConversation->sender_id : $this->selectedConversation->receiver_id;
        $this->receiver_id = $this->selectedConversation->sender_id == Auth::user()->id ? $this->selectedConversation->receiver_id : $this->selectedConversation->sender_id;
        if ($this->body == NULL) {
            return;
        }
        $createdMessage = Message::create([
            'conversation_id' => $this->selectedConversation->id,
            'sender_id' => $this->sender_id,
            'receiver_id' => $this->receiver_id,
            'body' => $this->body
        ]);
        $this->selectedConversation->last_time_message = $createdMessage->created_at;
        $this->selectedConversation->save();
        $this->dispatch('pushMessage', $createdMessage->id)->to('chat.chatbox');
        $this->dispatch('refresh', $createdMessage->id)->to('chat.chat-list');
        $this->body = '';
        $this->createdMessage = $createdMessage;
        $this->dispatch('dispatchMessageSent')->self();
    }
    public function dispatchMessageSent() {
        broadcast(new MessageSent(Auth::user(), $this->createdMessage, $this->selectedConversation, $this->receiver_id));
    }
    public function render()
    {
        return view('livewire.chat.send-message');
    }
}
