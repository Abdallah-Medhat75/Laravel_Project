<?php

namespace App\Repository;

use App\Models\Grade;
use App\Models\Quiz;
use App\Models\Subject;
use App\Models\Teacher;

class QuizzRepository implements QuizzRepositoryInterface
{
    public function index()
    {
        $quizzes = Quiz::get();
        return view('pages.Quizzes.index', compact('quizzes'));
    }
    public function create()
    {
        $data['grades'] = Grade::all();
        $data['subjects'] = Subject::all();
        $data['teachers'] = Teacher::all();
        return view('pages.Quizzes.create', $data);
    }
    public function store($request)
    {
        $quizzes = new Quiz();
        $quizzes->name = ['en' => $request->Name_en, 'ar' => $request->Name_ar];
        $quizzes->subject_id = $request->subject_id;
        $quizzes->grade_id = $request->Grade_id;
        $quizzes->classroom_id = $request->Classroom_id;
        $quizzes->section_id = $request->section_id;
        $quizzes->teacher_id = $request->teacher_id;
        $quizzes->save();
        session()->flash('quizzes_stored', trans('quizzes_trans.quizzes_stored'));
        return redirect()->route('Quizzes.create');
    }
    public function edit($id)
    {
        $quizz = Quiz::findorFail($id);
        $data['grades'] = Grade::all();
        $data['subjects'] = Subject::all();
        $data['teachers'] = Teacher::all();
        return view('pages.Quizzes.edit', $data, compact('quizz'));
    }
    public function update($request)
    {
        $quizz = Quiz::findorFail($request->id);
        $quizz->name = ['en' => $request->Name_en, 'ar' => $request->Name_ar];
        $quizz->subject_id = $request->subject_id;
        $quizz->grade_id = $request->Grade_id;
        $quizz->classroom_id = $request->Classroom_id;
        $quizz->section_id = $request->section_id;
        $quizz->teacher_id = $request->teacher_id;
        $quizz->save();
        session()->flash('quizzes_updated', trans('quizzes_trans.quizzes_updated'));
        return redirect('/quizzes');
    }
    public function destroy($request)
    {
        Quiz::destroy($request->id);
        session()->flash('quizzes_deleted', trans('quizzes_trans.quizzes_deleted'));
        return back();
    }
}
