<?php

namespace App\Repository;

interface TeacherDashboardRepositoryInterface {
    public function index();
    public function sections();
    public function attendance($request);
    public function attendanceReport();
    public function attendanceSearch($request);
}
