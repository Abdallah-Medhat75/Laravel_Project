<?php

namespace App\Repository;

use App\Models\Setting;
use App\Http\Traits\AttachFilesTrait;

class SettingRepository implements SettingRepositoryInterface {

    use AttachFilesTrait;

    public function index() {
        $collection = Setting::all();
        $setting['setting'] = $collection->flatMap(function ($collection) {
            return [$collection->key => $collection->value];
        });
        return view('pages.setting.index', $setting);
    }
    public function update($request){
        $info = $request->except('_token', '_method', 'logo');
        foreach ($info as $key => $value){
            Setting::where('key', $key)->update(['value' => $value]);
        }
        if ($request->hasFile('logo')) {
            $logo_name = $request->file('logo')->getClientOriginalName();
            $existedName = Setting::where('key', 'logo')->value('value');
            if ($logo_name != $existedName) {
                $this->deleteFile($existedName, 'logo');
                $this->uploadFile($request, 'logo', 'logo');
                Setting::where('key', 'logo')->update(['value' => $logo_name]);
            }
        }
        session()->flash('setting_updated', trans('setting_trans.setting_updated'));
        return back();
    }
}
