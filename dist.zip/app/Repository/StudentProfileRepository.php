<?php

namespace App\Repository;

use App\Models\Student;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class StudentProfileRepository implements StudentProfileRepositoryInterface {
    public function index()
    {
        $information = Student::findorFail(Auth::user()->id);
        return view('pages.Students.dashboard.profile', compact('information'));
    }
    public function update($request, $id)
    {
        $information = Student::findorFail($id);

        if (!empty($request->password)) {
            $information->name = ['en' => $request->Name_en, 'ar' => $request->Name_ar];
            $information->password = Hash::make($request->password);
            $information->save();
        } else {
            $information->name = ['en' => $request->Name_en, 'ar' => $request->Name_ar];
            $information->save();
        }
        session()->flash('profile_updated', trans('profile_trans.profile_updated'));
        return back();
    }
}
