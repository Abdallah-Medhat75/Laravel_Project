<?php

namespace App\Repository;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\Student;
use App\Models\Degree;
use App\Models\Attendance;
use App\Models\ReceiptStudents;
use App\Models\Fee_invoice;
use App\Models\My_Parent;

class ChildrenRepository implements ChildrenRepositoryInterface {
    public function index()
    {
        $students = Student::where('parent_id', Auth::user()->id)->get();
        return view('pages.parents.children.index', compact('students'));
    }
    public function results($id)
    {
        $student = Student::findorFail($id);
        if ($student->parent_id !== Auth::user()->id) {
            session()->flash('student_wrong_code', trans('Students_trans.student_wrong_code'));
            return redirect('/parent/children');
        }
        $degrees = Degree::where('student_id', $id)->get();
        if ($degrees->isEmpty()) {
            session()->flash('student_no_results', trans('Students_trans.student_no_results'));
            return redirect('/parent/children');
        }
        return view('pages.parents.degrees.index', compact('degrees'));
    }
    public function attendances()
    {
        $students = Student::where('parent_id', Auth::user()->id)->get();
        return view('pages.parents.Attendance.index', compact('students'));
    }
    public function attendanceSearch($request)
    {
        $request->validate([
            'from' => 'required|date|date_format:Y-m-d',
            'to' => 'required|date|date_format:Y-m-d|after_or_equal:from'
        ], [
            'to.after_or_equal' => 'تاريخ النهاية لابد ان اكبر من تاريخ البداية او يساويه',
            'from.date_format' => 'صيغة التاريخ يجب ان تكون yyyy-mm-dd',
            'to.date_format' => 'صيغة التاريخ يجب ان تكون yyyy-mm-dd',
        ]);
        $ids = DB::table('teacher_section')->where('teacher_id', Auth::user()->id)->pluck('section_id');
        $students = Student::whereIn('section_id', $ids)->get();
        if ($request->student_id == 0) {
            $Students = Attendance::whereBetween('attendence_date', [$request->from, $request->to])->get();
            return view('pages.parents.Attendance.index', compact('Students', 'students'));
        } else {
            $Students = Attendance::whereBetween('attendence_date', [$request->from, $request->to])
                ->where('student_id', $request->student_id)->get();
            return view('pages.parents.Attendance.index', compact('Students', 'students'));
        }
    }
    public function fees(){
        $students_ids = Student::where('parent_id', Auth::user()->id)->pluck('id');
        $Fee_invoices = Fee_invoice::whereIn('student_id',$students_ids)->get();
        return view('pages.parents.fees.index', compact('Fee_invoices'));
    }
    public function receiptStudent($id){
        $student = Student::findorFail($id);
        if ($student->parent_id !== Auth::user()->id) {

            return redirect('/parent/fees');
        }
        $receipt_students = ReceiptStudents::where('student_id',$id)->get();
        if ($receipt_students->isEmpty()) {

            return redirect('/parent/fees');
        }
        return view('pages.parents.Receipt.index', compact('receipt_students'));
    }
    public function profile()
    {
        $information = My_Parent::findorFail(Auth::user()->id);
        return view('pages.parents.profile', compact('information'));
    }
    public function update($request, $id)
    {
        $information = My_Parent::findorFail($id);

        if (!empty($request->password)) {
            $information->Name_Father = ['en' => $request->Name_en, 'ar' => $request->Name_ar];
            $information->password = Hash::make($request->password);
            $information->save();
        } else {
            $information->Name_Father = ['en' => $request->Name_en, 'ar' => $request->Name_ar];
            $information->save();
        }
        session()->flash('profile_updated', trans('profile_trans.profile_updated'));
        return back();
    }
}
