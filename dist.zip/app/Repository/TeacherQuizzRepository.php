<?php

namespace App\Repository;
use App\Models\Grade;
use App\Models\Classroom;
use App\Models\Section;
use App\Models\Subject;
use App\Models\Quiz;
use App\Models\Question;
use App\Models\Degree;
use Illuminate\Support\Facades\Auth;

class TeacherQuizzRepository implements TeacherQuizzRepositoryInterface {
    public function index()
    {
        $quizzes = Quiz::where('teacher_id', Auth::user()->id)->get();
        return view('pages.Teachers.dashboard.Quizzes.index', compact('quizzes'));
    }
    public function create()
    {
        $data['grades'] = Grade::all();
        $data['subjects'] = Subject::where('teacher_id', Auth::user()->id)->get();
        return view('pages.Teachers.dashboard.Quizzes.create', $data);
    }
    public function store($request)
    {
        $quizzes = new Quiz();
        $quizzes->name = ['en' => $request->Name_en, 'ar' => $request->Name_ar];
        $quizzes->subject_id = $request->subject_id;
        $quizzes->grade_id = $request->Grade_id;
        $quizzes->classroom_id = $request->Classroom_id;
        $quizzes->section_id = $request->section_id;
        $quizzes->teacher_id = Auth::user()->id;
        $quizzes->save();
        session()->flash('quizzes_stored', trans('quizzes_trans.quizzes_stored'));
        return redirect('/teacher/quizzes/create');
    }
    public function show($id) {
        $questions = Question::where('quiz_id',$id)->get();
        $quizz = Quiz::findorFail($id);
        return view('pages.Teachers.dashboard.Questions.index',compact('questions','quizz'));
    }
    public function edit($id)
    {
        $quizz = Quiz::findorFail($id);
        $data['grades'] = Grade::all();
        $data['subjects'] = Subject::where('teacher_id', Auth::user()->id)->get();
        return view('pages.Teachers.dashboard.Quizzes.edit', $data, compact('quizz'));
    }
    public function update($request)
    {
        $quizz = Quiz::findorFail($request->id);
        $quizz->name = ['en' => $request->Name_en, 'ar' => $request->Name_ar];
        $quizz->subject_id = $request->subject_id;
        $quizz->grade_id = $request->Grade_id;
        $quizz->classroom_id = $request->Classroom_id;
        $quizz->section_id = $request->section_id;
        $quizz->teacher_id = Auth::user()->id;
        $quizz->save();
        session()->flash('quizzes_updated', trans('quizzes_trans.quizzes_updated'));
        return redirect('/teacher/quizzes');
    }
    public function destroy($id)
    {
        Quiz::destroy($id);
        session()->flash('quizzes_deleted', trans('quizzes_trans.quizzes_deleted'));
        return back();
    }
    public function getClassrooms($id)
    {
        $list_classes = Classroom::where("Grade_id", $id)->pluck("Name_Class", "id");
        return $list_classes;
    }
    public function Get_Sections($id) {
        $list_sections = Section::where("Class_id", $id)->pluck("Name_Section", "id");
        return $list_sections;
    }
    public function student_quizze($quizze_id)
    {
        $degrees = Degree::where('quizze_id', $quizze_id)->get();
        return view('pages.Teachers.dashboard.Quizzes.student_quizze', compact('degrees'));
    }
    public function repeat_quizze($request)
    {
        Degree::where('student_id', $request->student_id)->where('quizze_id', $request->quizze_id)->delete();
        session()->flash('quizzes_opened', trans('quizzes_trans.quizzes_opened'));
        return redirect()->back();
    }
}
