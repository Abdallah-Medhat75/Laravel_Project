<?php

namespace App\Repository;

use App\Models\Question;
use App\Models\Quiz;

class QuestionRepository implements QuestionRepositoryInterface
{

    public function index()
    {
        $questions = Question::get();
        return view('pages.Questions.index', compact('questions'));
    }

    public function create()
    {
        $quizzes = Quiz::get();
        return view('pages.Questions.create',compact('quizzes'));
    }

    public function store($request)
    {
        $question = new Question();
        $question->title = $request->title;
        $question->answers = $request->answers;
        $question->right_answer = $request->right_answer;
        $question->score = $request->score;
        $question->quiz_id = $request->quiz_id;
        $question->save();
        session()->flash('questions_stored', trans('questions_trans.questions_stored'));
        return redirect()->route('questions.create');
    }

    public function edit($id)
    {
        $question = Question::findorfail($id);
        $quizzes = Quiz::get();
        return view('pages.Questions.edit',compact('question','quizzes'));
    }

    public function update($request)
    {
        $question = Question::findorfail($request->id);
        $question->title = $request->title;
        $question->answers = $request->answers;
        $question->right_answer = $request->right_answer;
        $question->score = $request->score;
        $question->quiz_id = $request->quiz_id;
        $question->save();
        session()->flash('questions_updated', trans('questions_trans.questions_updated'));
        return redirect('/questions');
    }

    public function destroy($request)
    {
        Question::destroy($request->id);
        session()->flash('questions_deleted', trans('questions_trans.questions_deleted'));
        return back();
    }
}
