<?php

namespace App\Repository;

interface TeacherProfileRepositoryInterface {
    public function index();
    public function update($request, $id);
}
