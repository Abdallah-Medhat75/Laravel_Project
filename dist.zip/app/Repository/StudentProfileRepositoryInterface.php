<?php

namespace App\Repository;

interface StudentProfileRepositoryInterface {
    public function index();
    public function update($request, $id);
}
