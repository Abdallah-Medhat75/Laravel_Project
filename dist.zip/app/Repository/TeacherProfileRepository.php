<?php

namespace App\Repository;

use App\Models\Teacher;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class TeacherProfileRepository implements TeacherProfileRepositoryInterface {
    public function index()
    {
        $information = Teacher::findorFail(Auth::user()->id);
        return view('pages.Teachers.dashboard.profile', compact('information'));
    }
    public function update($request, $id)
    {
        $information = Teacher::findorFail($id);

        if (!empty($request->password)) {
            $information->Name = ['en' => $request->Name_en, 'ar' => $request->Name_ar];
            $information->password = Hash::make($request->password);
            $information->save();
        } else {
            $information->Name = ['en' => $request->Name_en, 'ar' => $request->Name_ar];
            $information->save();
        }
        session()->flash('profile_updated', trans('profile_trans.profile_updated'));
        return redirect()->back();
    }
}
