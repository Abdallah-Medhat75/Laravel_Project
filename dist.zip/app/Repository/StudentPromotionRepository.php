<?php

    namespace App\Repository;
    use App\Models\Grade;
    use App\Models\Student;
    use App\Models\Promotion;

    class StudentPromotionRepository implements StudentPromotionRepositoryInterface {
        public function index() {
            $Grades = Grade::all();
            return view('pages.Students.promotion.index', compact('Grades'));
        }
        public function create() {
            $promotions = Promotion::all();
            return view('pages.Students.promotion.management', compact('promotions'));
        }
        public function store($request) {
            $students = Student::where('Grade_id', $request->Grade_id)->where('Classroom_id', $request->Classroom_id)->where('section_id', $request->section_id)->where('academic_year',$request->academic_year)->get();
            if ($students->count() < 1){
                return redirect()->back()->with('error_promotions', __(trans('Students_trans.no_data')));
            }
            // update in table student
            foreach ($students as $student){
                $ids = explode(',', $student->id);
                Student::whereIn('id', $ids)
                    ->update([
                        'Grade_id' => $request->Grade_id_new,
                        'Classroom_id' => $request->Classroom_id_new,
                        'section_id' => $request->section_id_new,
                        'academic_year' => $request->academic_year_new,
                    ]);
                // insert into promotions
                Promotion::updateOrCreate([
                    'student_id' => $student->id,
                    'from_grade' => $request->Grade_id,
                    'from_Classroom' => $request->Classroom_id,
                    'from_section' => $request->section_id,
                    'to_grade' => $request->Grade_id_new,
                    'to_Classroom' => $request->Classroom_id_new,
                    'to_section' => $request->section_id_new,
                    'academic_year' => $request->academic_year,
                    'academic_year_new' => $request->academic_year_new,
                ]);
            }
            session()->flash('promotion_success', trans('Students_trans.promotion_success'));
            return back();
        }
        public function destroy($request) {
            if ($request->page_id == 1) {
                $Promotions = Promotion::all();
                foreach ($Promotions as $Promotion) {
                    $ids = explode(',', $Promotion->student_id);
                    student::whereIn('id', $ids)
                    ->update([
                        'Grade_id'=>$Promotion->from_grade,
                        'Classroom_id'=>$Promotion->from_Classroom,
                        'section_id'=> $Promotion->from_section,
                        'academic_year'=>$Promotion->academic_year,
                    ]);
                }
                Promotion::truncate();
                session()->flash('student_rollback_success', trans('Students_trans.student_rollback_success'));
                return back();
            } else {
                $Promotion = Promotion::findorfail($request->id);
                Student::where('id', $Promotion->student_id)
                    ->update([
                        'Grade_id'=>$Promotion->from_grade,
                        'Classroom_id'=>$Promotion->from_Classroom,
                        'section_id'=> $Promotion->from_section,
                        'academic_year'=>$Promotion->academic_year,
                    ]);
                Promotion::destroy($request->id);
                session()->flash('student_only_rollback_success', trans('Students_trans.student_only_rollback_success'));
                return back();
            }
        }
    }
