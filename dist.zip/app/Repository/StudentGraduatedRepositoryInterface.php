<?php

namespace App\Repository;

interface StudentGraduatedRepositoryInterface {
    public function index();
    public function create();
    public function SoftDelete($request);
    public function destroy($request);
    public function ReturnData($request);
}
