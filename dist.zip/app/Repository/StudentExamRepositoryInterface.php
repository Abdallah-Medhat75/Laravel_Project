<?php

namespace App\Repository;

interface StudentExamRepositoryInterface {
    public function index();
    public function show($id);
}
