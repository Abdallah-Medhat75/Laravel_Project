<?php

namespace App\Repository;
use App\Models\Teacher;
use App\Models\Specialization;
use App\Models\Gender;
use App\Models\Student;
use GuzzleHttp\Psr7\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class TeacherRepository implements TeacherRepositoryInterface {
    public function getAllTeachers() {
        return Teacher::all();
    }
    public function getAllSpecializations() {
        return Specialization::all();;
    }
    public function getAllGenders() {
        return Gender::all();
    }
    public function StoreTeachers($request) {
        $Teachers = new Teacher();
        $Teachers->Email = $request->Email;
        $Teachers->Password = Hash::make($request->Password);
        $Teachers->Name = ['en' => $request->Name_en, 'ar' => $request->Name_ar];
        $Teachers->Specialization_id = $request->Specialization_id;
        $Teachers->Gender_id = $request->Gender_id;
        $Teachers->Joining_Date = $request->Joining_Date;
        $Teachers->Address = $request->Address;
        $Teachers->save();
        session()->flash('teachers_added', trans('Teacher_trans.teachers_added'));
        return back();
        // This Works too
        // return redirect('teachers/create');
    }
    public function EditTeachers($id) {
        return Teacher::findOrFail($id);
    }
    public function UpdateTeachers($request) {
        $Teachers = Teacher::findOrFail($request->id);
        $Teachers->Email = $request->Email;
        $Teachers->Password =  Hash::make($request->Password);
        $Teachers->Name = ['en' => $request->Name_en, 'ar' => $request->Name_ar];
        $Teachers->Specialization_id = $request->Specialization_id;
        $Teachers->Gender_id = $request->Gender_id;
        $Teachers->Joining_Date = $request->Joining_Date;
        $Teachers->Address = $request->Address;
        $Teachers->save();
        session()->flash('teachers_edit', trans('Teacher_trans.teachers_edit'));
        return back();
    }
    public function DeleteTeachers($request) {
        Teacher::find($request->id)->delete();
        session()->flash('teachers_deleted', trans('Teacher_trans.teachers_deleted'));
        return back();
    }
    public function dashboard() {
        $ids = Teacher::findorFail(Auth::user()->id)->Sections()->pluck('section_id');
        $data['count_sections']= $ids->count();
        $data['count_students']= Student::whereIn('section_id', $ids)->count();
        return view('pages.Teachers.dashboard.dashboard', $data);
    }
}
