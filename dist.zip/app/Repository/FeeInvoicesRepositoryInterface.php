<?php

namespace App\Repository;

interface FeeInvoicesRepositoryInterface {
    public function index();
    public function store($request);
    public function show($id);
    public function edit($id);
    public function update($id);
    public function destroy($id);
}
