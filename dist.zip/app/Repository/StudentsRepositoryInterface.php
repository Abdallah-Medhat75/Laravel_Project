<?php

namespace App\Repository;

interface StudentsRepositoryInterface {
    public function showStudents();
    public function createStudents();
    public function Get_classrooms($id);
    public function Get_Sections($id);
    public function Store_Student($request);
    public function editStudent($id);
    public function updateStudent($request);
    public function deleteStudent($request);
    public function showAttachments($id);
    public function Upload_attachment($request);
    public function Delete_attachment($request);
    public function Download_attachment($studentsname, $filename);
}
