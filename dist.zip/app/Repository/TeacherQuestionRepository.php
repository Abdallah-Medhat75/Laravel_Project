<?php

namespace App\Repository;

use App\Models\Question;

class TeacherQuestionRepository implements TeacherQuestionRepositoryInterface {
    public function store($request)
    {
        $question = new Question();
        $question->title = $request->title;
        $question->answers = $request->answers;
        $question->right_answer = $request->right_answer;
        $question->score = $request->score;
        $question->quiz_id = $request->quizz_id;
        $question->save();
        session()->flash('questions_stored', trans('questions_trans.questions_stored'));
        return back();
    }
    public function create($id)
    {
        $quizz_id = $id;
        return view('pages.Teachers.dashboard.Questions.create', compact('quizz_id'));
    }
    public function edit($id)
    {
        $question = Question::findorFail($id);
        return view('pages.Teachers.dashboard.Questions.edit', compact('question'));
    }
    public function update($request, $id)
    {
        $question = Question::findorfail($id);
        $question->title = $request->title;
        $question->answers = $request->answers;
        $question->right_answer = $request->right_answer;
        $question->score = $request->score;
        $question->save();
        session()->flash('questions_updated', trans('questions_trans.questions_updated'));
        return back();
    }
    public function destroy($id)
    {
        Question::destroy($id);
        session()->flash('questions_deleted', trans('questions_trans.questions_deleted'));
        return back();
    }
}
