<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Repository\TeacherRepositoryInterface;
use App\Repository\StudentsRepositoryInterface;
use App\Repository\StudentPromotionRepositoryInterface;
use App\Repository\StudentGraduatedRepositoryInterface;
use App\Repository\FeesRepositoryInterface;
use App\Repository\FeeInvoicesRepositoryInterface;
use App\Repository\ReceiptStudentsRepositoryInterface;
use App\Repository\ProcessingFeeRepositoryInterface;
use App\Repository\PaymentRepositoryInterface;
use App\Repository\AttendanceRepositoryInterface;
use App\Repository\SubjectRepositoryInterface;
use App\Repository\QuizzRepositoryInterface;
use App\Repository\QuestionRepositoryInterface;
use App\Repository\OnlineClassesRepositoryInterface;
use App\Repository\LibraryRepositoryInterface;
use App\Repository\SettingRepositoryInterface;
use App\Repository\TeacherDashboardRepositoryInterface;
use App\Repository\TeacherQuizzRepositoryInterface;
use App\Repository\TeacherQuestionRepositoryInterface;
use App\Repository\TeacherProfileRepositoryInterface;
use App\Repository\StudentExamRepositoryInterface;
use App\Repository\StudentProfileRepositoryInterface;
use App\Repository\ChildrenRepositoryInterface;

use App\Repository\TeacherRepository;
use App\Repository\StudentsRepository;
use App\Repository\StudentPromotionRepository;
use App\Repository\StudentGraduatedRepository;
use App\Repository\FeesRepository;
use App\Repository\FeeInvoicesRepository;
use App\Repository\ReceiptStudentsRepository;
use App\Repository\ProcessingFeeRepository;
use App\Repository\PaymentRepository;
use App\Repository\AttendanceRepository;
use App\Repository\SubjectRepository;
use App\Repository\QuizzRepository;
use App\Repository\QuestionRepository;
use App\Repository\OnlineClassesRepository;
use App\Repository\LibraryRepository;
use App\Repository\SettingRepository;
use App\Repository\TeacherDashboardRepository;
use App\Repository\TeacherQuizzRepository;
use App\Repository\TeacherQuestionRepository;
use App\Repository\TeacherProfileRepository;
use App\Repository\StudentExamRepository;
use App\Repository\StudentProfileRepository;
use App\Repository\ChildrenRepository;

class RepoServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        $this->app->bind(TeacherRepositoryInterface::class, TeacherRepository::class);
        $this->app->bind(StudentsRepositoryInterface::class, StudentsRepository::class);
        $this->app->bind(StudentPromotionRepositoryInterface::class, StudentPromotionRepository::class);
        $this->app->bind(StudentGraduatedRepositoryInterface::class, StudentGraduatedRepository::class);
        $this->app->bind(FeesRepositoryInterface::class, FeesRepository::class);
        $this->app->bind(FeeInvoicesRepositoryInterface::class, FeeInvoicesRepository::class);
        $this->app->bind(ReceiptStudentsRepositoryInterface::class, ReceiptStudentsRepository::class);
        $this->app->bind(ProcessingFeeRepositoryInterface::class, ProcessingFeeRepository::class);
        $this->app->bind(ProcessingFeeRepositoryInterface::class, ProcessingFeeRepository::class);
        $this->app->bind(PaymentRepositoryInterface::class, PaymentRepository::class);
        $this->app->bind(AttendanceRepositoryInterface::class, AttendanceRepository::class);
        $this->app->bind(SubjectRepositoryInterface::class, SubjectRepository::class);
        $this->app->bind(QuizzRepositoryInterface::class, QuizzRepository::class);
        $this->app->bind(QuestionRepositoryInterface::class, QuestionRepository::class);
        $this->app->bind(OnlineClassesRepositoryInterface::class, OnlineClassesRepository::class);
        $this->app->bind(LibraryRepositoryInterface::class, LibraryRepository::class);
        $this->app->bind(SettingRepositoryInterface::class, SettingRepository::class);
        $this->app->bind(TeacherDashboardRepositoryInterface::class, TeacherDashboardRepository::class);
        $this->app->bind(TeacherQuizzRepositoryInterface::class, TeacherQuizzRepository::class);
        $this->app->bind(TeacherQuestionRepositoryInterface::class, TeacherQuestionRepository::class);
        $this->app->bind(TeacherProfileRepositoryInterface::class, TeacherProfileRepository::class);
        $this->app->bind(StudentExamRepositoryInterface::class, StudentExamRepository::class);
        $this->app->bind(StudentProfileRepositoryInterface::class, StudentProfileRepository::class);
        $this->app->bind(ChildrenRepositoryInterface::class, ChildrenRepository::class);
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        //
    }
}
