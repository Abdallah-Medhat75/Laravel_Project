<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Auth;

class MessageSent implements ShouldBroadcastNow
{
    public $user_id, $user, $conversation, $message, $receiver_id;
    use Dispatchable, InteractsWithSockets, SerializesModels;
    public function __construct($conversation, $message, $receiver_id)
    {
        $this->conversation = $conversation;
        $this->message = $message;
        $this->receiver_id = $receiver_id;
    }
    public function broadcastWith() {
        return [
            'conversation_id' => $this->conversation->id,
            'message_id' => $this->message->id,
            'receiver_id' => $this->receiver_id,
        ];
    }
    public function broadcastOn(): array
    {
        return [
            new PrivateChannel("users.{$this->receiver_id}"),
        ];
    }
}
