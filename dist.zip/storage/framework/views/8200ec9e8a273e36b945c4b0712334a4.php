<?php $__env->startSection('css'); ?>
@toastr_css
<?php $__env->startSection('title'); ?>
الفواتير الدراسية
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
الفواتير الدراسية
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- row -->
<div class="row">
    <div class="col-md-12 mb-30">
        <div class="card card-statistics h-100">
            <div class="card-body">
                <div class="col-xl-12 mb-30">
                    <div class="card card-statistics h-100">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                       data-page-length="50"
                                       style="text-align: center">
                                    <thead>
                                    <tr class="alert-success">
                                        <th>#</th>
                                        <th>الاسم</th>
                                        <th>نوع الرسوم</th>
                                        <th>المبلغ</th>
                                        <th>المرحلة الدراسية</th>
                                        <th>الصف الدراسي</th>
                                        <th>البيان</th>
                                        <th>العمليات</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $Fee_invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Fee_invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($Fee_invoice->student->name); ?></td>
                                        <td><?php echo e($Fee_invoice->fees->title); ?></td>
                                        <td><?php echo e(number_format($Fee_invoice->amount, 2)); ?></td>
                                        <td><?php echo e($Fee_invoice->grade->Name); ?></td>
                                        <td><?php echo e($Fee_invoice->classroom->Name_Class); ?></td>
                                        <td><?php echo e($Fee_invoice->description); ?></td>
                                        <td>
                                            <a href='<?php echo e(url(app()->getLocale() . "/parent/receipt/{$Fee_invoice->student_id}")); ?>' title="المدفوعات" class="btn btn-info btn-sm" role="button" aria-pressed="true">
                                                <i class="fa fa-file-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
@toastr_js
@toastr_render
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\schools\resources\views/pages/parents/fees/index.blade.php ENDPATH**/ ?>