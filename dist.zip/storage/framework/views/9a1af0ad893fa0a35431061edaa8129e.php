<div>
    <div>
        <div class="card card-statistics mb-30">
            <div class="card-body">
                <h5 class="card-title"> <?php echo e($data[$counter]->title); ?></h5>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = preg_split('/(-)/', $data[$counter]->answers); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="custom-control custom-radio">
                        <input type="radio" id="customRadio<?php echo e($index); ?>" name="customRadio" class="custom-control-input" inh>
                        <label class="custom-control-label" for="customRadio<?php echo e($index); ?>" wire:click="nextQuestion(<?php echo e($data[$counter]->id); ?>, <?php echo e($data[$counter]->score); ?>, '<?php echo e($answer); ?>', '<?php echo e($data[$counter]->right_answer); ?>')"> <?php echo e($answer); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\schools\resources\views/livewire/show-question.blade.php ENDPATH**/ ?>