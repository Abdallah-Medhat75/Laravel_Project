<?php $__env->startSection('css'); ?>
    @toastr_css
    <?php $__env->startSection('title'); ?>
        قائمة الطلاب المختبره
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
    <?php $__env->startSection('PageTitle'); ?>
        قائمة الطلاب المختبره
    <?php $__env->stopSection(); ?>
    <!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <div class="col-xl-12 mb-30">
                        <?php if(session()->has('quizzes_opened')): ?>
                            <div class="alert alert-success"><?php echo e(session()->get('quizzes_opened')); ?></div>
                        <?php endif; ?>
                        <div class="card card-statistics h-100">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                           data-page-length="50"
                                           style="text-align: center">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>اسم الطالب</th>
                                            <th>اخر سؤال</th>
                                            <th>الدرجة</th>
                                            <th>تلاعب</th>
                                            <th>تاريخ اجراء الاختبار</th>
                                            <th>العمليات</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($degree->student->name); ?></td>
                                                <td><?php echo e($degree->question_id); ?></td>
                                                <td><?php echo e($degree->score); ?></td>
                                                <?php if($degree->abuse == 0): ?>
                                                    <td style="color: green">لا يوجد تلاعب</td>
                                                <?php else: ?>
                                                    <td style="color: red"> يوجد تلاعب</td>
                                                <?php endif; ?>
                                                <td><?php echo e($degree->date); ?></td>
                                                <td>
                                                    <button type="button" class="btn btn-info btn-sm"
                                                            data-toggle="modal"
                                                            data-target="#repeat_quizze<?php echo e($degree->quizze_id); ?>" title="إعادة">
                                                        <i class="fas fa-repeat"></i></button>
                                                </td>
                                            </tr>

                                            <div class="modal fade" id="repeat_quizze<?php echo e($degree->quizze_id); ?>" tabindex="-1"
                                                 role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <form action='<?php echo e(url(app()->getLocale() . "/teacher/quizzes/repeat_quizze")); ?>' method="post">
                                                        <?php echo e(method_field('post')); ?>

                                                        <?php echo e(csrf_field()); ?>

                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 style="font-family: 'Cairo', sans-serif;"
                                                                    class="modal-title" id="exampleModalLabel">فتح إعادة الاختبار للطالب</h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                        aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <h6><?php echo e($degree->student->name); ?></h6>
                                                                <input type="hidden" name="student_id" value="<?php echo e($degree->student_id); ?>">
                                                                <input type="hidden" name="quizze_id" value="<?php echo e($degree->quizze_id); ?>">
                                                            </div>
                                                            <div class="modal-footer">
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                            data-dismiss="modal"><?php echo e(trans('My_Classes_trans.Close')); ?></button>
                                                                    <button type="submit"
                                                                            class="btn btn-info"><?php echo e(trans('My_Classes_trans.submit')); ?></button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    @toastr_js
    @toastr_render
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\schools\resources\views/pages/Teachers/dashboard/Quizzes/student_quizze.blade.php ENDPATH**/ ?>