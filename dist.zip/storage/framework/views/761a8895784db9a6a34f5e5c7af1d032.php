<div>
    <ul class="list-group w-75 mx-auto container-fluid">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item" wire:click='checkConversation(<?php echo e($user->id); ?>)'><?php echo e($user->name); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </ul>
</div>
<?php /**PATH C:\laragon\www\chat\resources\views/livewire/chat/create-chat.blade.php ENDPATH**/ ?>