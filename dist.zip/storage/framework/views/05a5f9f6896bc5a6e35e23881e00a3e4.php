<div class="container-fluid">
    <div class="row">
        <div class="side-menu-fixed">
            <?php if(auth('web')->check()): ?>
                <?php echo $__env->make('layouts.main-sidebar.admin-main-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php elseif(auth('student')->check()): ?>
                <?php echo $__env->make('layouts.main-sidebar.student-main-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php elseif(auth('teacher')->check()): ?>
                <?php echo $__env->make('layouts.main-sidebar.teacher-main-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php elseif(auth('parent')->check()): ?>
                <?php echo $__env->make('layouts.main-sidebar.parent-main-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
        </div>
<?php /**PATH C:\laragon\www\schools\resources\views/layouts/main-sidebar.blade.php ENDPATH**/ ?>