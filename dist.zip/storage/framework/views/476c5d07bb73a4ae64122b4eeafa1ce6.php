<div>
    <!--[if BLOCK]><![endif]--><?php if($selectedConversation): ?>
        <div class="chatbox-header">
            <div class="return">
                <i class="fa-solid fa-arrow-left"></i>
            </div>
            <div class="img-container">
                <img src='<?php echo e(asset("attachements/{$receiverInstance->profile}")); ?>' alt="">
            </div>
            <div class="name">
                <?php echo e($receiverInstance->name); ?>

            </div>
            <div class="info">
                <div class="info-item">
                    <i class="fa-solid fa-phone"></i>
                </div>
                <div class="info-item">
                    <i class="fa-regular fa-image"></i>
                </div>
                <div class="info-item">
                    <i class="fa-solid fa-circle-info"></i>
                </div>
            </div>
        </div>
        <div class="chatbox-body">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="msg-body <?php echo e($message->receiver_id == auth()->user()->id ? 'me' : 'receiver'); ?>" wire:key='<?php echo e($message->id); ?>'>
                    <?php echo e($message->body); ?>

                    <div class="msg-body-footer">
                        <div class="date">
                            <?php echo e($message->created_at->format('m:i a')); ?>

                        </div>
                        <div class="read">
                            <!--[if BLOCK]><![endif]--><?php if($message->user->id === auth()->user()->id): ?>
                                <!--[if BLOCK]><![endif]--><?php if($message->read == 0): ?>
                                    <i class="fa-solid fa-check"></i>
                                <?php else: ?>
                                    <i class="fa-solid fa-check-double"></i>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    <?php else: ?>
        <div class="fs-4 text-center text-primary mt-5">
            No Conversation Selected
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <script src='<?php echo e(asset('assets/js/chatbox.js')); ?>'></script>
</div>
<?php /**PATH C:\laragon\www\chat\resources\views/livewire/chat/chatbox.blade.php ENDPATH**/ ?>