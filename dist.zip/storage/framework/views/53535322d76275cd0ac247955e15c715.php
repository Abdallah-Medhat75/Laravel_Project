<div x-data="{ height: 0 }" x-init="height = $refs.conversation.scrollHeight; $nextTick(() => $refs.conversation.scrollTop = height)" @scroll-bottom.window="$nextTick(() => $refs.conversation.scrollTop = height)" class="w-full overflow-y-auto">
    <div class="border-b flex flex-col overflow-y-auto grow h-full">
        <header class="w-full sticky inset-x-0 flex pb-[5px] pt-[5px] top-0 z-10 bg-white border-b">
            <div class="flex w-full items-center px-2 lg:px-4 gap-2 md:gap-5">
                <a class="shrink-0 lg:hidden" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 15.75 3 12m0 0 3.75-3.75M3 12h18" />
                    </svg>
                </a>
                <div class="shirnk-0">
                    <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => ''.e($selectedConversation->getReceiver()->profile == NULL ? $selectedConversation->placeholder : asset("attachments/{$selectedConversation->getReceiver()->profile}")).'','class' => 'h-9 w-9 lg:w-11 lg:h-11']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => ''.e($selectedConversation->getReceiver()->profile == NULL ? $selectedConversation->placeholder : asset("attachments/{$selectedConversation->getReceiver()->profile}")).'','class' => 'h-9 w-9 lg:w-11 lg:h-11']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                </div>
                <h6 class="font-bold truncate">
                    <?php echo e($selectedConversation->getReceiver()->name); ?>

                </h6>
            </div>
        </header>
        <main @scroll="scrollTop = $el.scrollTop; if (scrollTop <= 0) {window.Livewire.dispatch('loadMore')}" @update-chat-height.window="newHeight = $el.scrollHeight; oldHeight = height; $el.scrollTop = newHeight - oldHeight; height = newHeight;" x-ref="conversation" class="flex flex-col gap-3 p-2.5 overflow-y-auto flex-grow overscroll-contain overflow-x-hidden w-full my-auto">
            <?php
                $previousMessage = NULL;
            ?>
            <?php $__empty_1 = true; $__currentLoopData = $loadedMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <!--[if BLOCK]><![endif]--><?php if($key > 0): ?>
                    <?php
                        $previousMessage = $loadedMessages->get($key - 1);
                    ?>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['max-w-[85%] md:max-w-[78%] flex w-auto gap-2 relative mt-2', 'ml-auto' => $message->sender_id == auth()->id()]); ?>">
                    
                    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['shrink-0', 'invisible' => $previousMessage?->sender_id === $message->sender_id, 'hidden' => $message->sender_id === auth()->id()]); ?>">
                        <?php if (isset($component)) { $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.avatar','data' => ['src' => ''.e($selectedConversation->getReceiver()->profile == NULL ? $selectedConversation->placeholder : asset("attachments/{$selectedConversation->getReceiver()->profile}")).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => ''.e($selectedConversation->getReceiver()->profile == NULL ? $selectedConversation->placeholder : asset("attachments/{$selectedConversation->getReceiver()->profile}")).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $attributes = $__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__attributesOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b)): ?>
<?php $component = $__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b; ?>
<?php unset($__componentOriginal8ca5b43b8fff8bb34ab2ba4eb4bdd67b); ?>
<?php endif; ?>
                    </div>
                        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses(['flex flex-wrap text-[15px] rounded-xl p-2.5 flex-col text-black bg-[#f6f6f8]','rounded-bl-none border border-gray-200/40' => !($message->sender_id == auth()->id()),'rounded-br-none bg-blue-500/80 text-white' => $message->sender_id == auth()->id()]); ?>">
                            <p class="whitespace-normal trunate text-sm md:text-base tracking-wide lg:tracking-normal">
                                <?php echo e($message->body); ?>

                            </p>
                            <div class="ml-auto flex gap-2">
                                <p class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-xs', 'text-gray-200' => !($message->sender_id == auth()->id()), 'text-white' => $message->sender_id == auth()->id()]); ?>">
                                    <?php echo e($message->created_at->format('g: i a')); ?>

                                </p>
                                <!--[if BLOCK]><![endif]--><?php if($message->sender_id === auth()->id()): ?>
                                    <div>
                                        <!--[if BLOCK]><![endif]--><?php if($message->isRead()): ?>
                                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-white']); ?>">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2-all" viewBox="0 0 16 16">
                                                    <path d="M12.354 4.354a.5.5 0 0 0-.708-.708L5 10.293 1.854 7.146a.5.5 0 1 0-.708.708l3.5 3.5a.5.5 0 0 0 .708 0zm-4.208 7-.896-.897.707-.707.543.543 6.646-6.647a.5.5 0 0 1 .708.708l-7 7a.5.5 0 0 1-.708 0"/>
                                                    <path d="m5.354 7.146.896.897-.707.707-.897-.896a.5.5 0 1 1 .708-.708"/>
                                                </svg>
                                            </span>
                                        <?php else: ?>
                                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-white']); ?>">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16">
                                                    <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/>
                                                </svg>
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                No Messages Yet
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </main>
        <footer class="shrink-0 z-10 bg-white inset-x-0">
            <div class="p-2 border-t">
                <form
                    x-data="{body:<?php if ((object) ('body') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('body'->value()); ?>')<?php echo e('body'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('body'); ?>')<?php endif; ?>}"
                    @submit.prevent="$wire.sendMessage"
                    method="POST" autocapitalize="off">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="" autocomplete="off" style="display:none">
                    <div class="grid grid-cols-12">
                        <input x-model="body" type="text" autocomplete="off" autofocus placeholder="Write Your Message Here" maxlength="1700" class="col-span-10 bg-gray-100 border-0 outline-0 focus:border-0 focus:ring-0 hover:ring-0 rounded-lg focus:outline-none">
                        <button x-bind:disabled="!body || !body.trim()" class="col-span-2" type="submit" disabled="disabled">Send</button>
                    </div>
                </form>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </footer>
    </div>
</div>
<?php /**PATH F:\backups\playlists\practice\advanced-chat\resources\views/livewire/chat/chat-box.blade.php ENDPATH**/ ?>