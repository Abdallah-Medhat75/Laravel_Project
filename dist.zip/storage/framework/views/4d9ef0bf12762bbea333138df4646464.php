<div class="scrollbar side-menu-bg" style="overflow: scroll">
    <ul class="nav navbar-nav side-menu" id="sidebarnav">
        <!-- menu item Dashboard-->
        <li>
            <a href='<?php echo e(url(app()->getLocale() . "/parent/dashboard")); ?>'>
                <div class="pull-left">
                    <i class="ti-home"></i>
                    <span class="right-nav-text"><?php echo e(trans('main_trans.Dashboard')); ?></span>
                </div>
                <div class="clearfix"></div>
            </a>
        </li>
        <!-- menu title -->
        <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title"><?php echo e(trans('main_trans.Programname')); ?> </li>
        <!-- الامتحانات-->
        <li>
            <a href='<?php echo e(url(app()->getLocale() . "/parent/children")); ?>'>
                <i class="fas fa-book-open"></i>
                <span class="right-nav-text">الابناء</span>
            </a>
        </li>
        <!-- تقرير الحضور والغياب-->
        <li>
            <a href='<?php echo e(url(app()->getLocale() . "/parent/attendances")); ?>'>
                <i class="fas fa-book-open"></i>
                <span class="right-nav-text">تقرير الحضور والغياب</span>
            </a>
        </li>
        <!-- تقرير المالية-->
        <li>
            <a href='<?php echo e(url(app()->getLocale() . "/parent/fees")); ?>'>
                <i class="fas fa-book-open"></i>
                <span class="right-nav-text">تقرير المالية</span>
            </a>
        </li>
        <!-- Settings-->
        <li>
            <a href='<?php echo e(url(app()->getLocale() . "/parent/profile")); ?>'>
                <i class="fas fa-id-card-alt"></i>
                <span class="right-nav-text">الملف الشخصي</span>
            </a>
        </li>
    </ul>
</div>
<?php /**PATH C:\laragon\www\schools\resources\views/layouts/main-sidebar/parent-main-sidebar.blade.php ENDPATH**/ ?>