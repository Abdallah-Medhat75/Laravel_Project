<div class="scrollbar side-menu-bg" style="overflow: scroll">
    <ul class="nav navbar-nav side-menu" id="sidebarnav">
        <!-- menu item Dashboard-->
        <li>
            <a href="<?php echo e(url('/dashboard')); ?>">
                <div class="pull-left"><i class="ti-home"></i><span
                        class="right-nav-text"><?php echo e(trans('main_trans.Dashboard')); ?></span>
                </div>
                <div class="clearfix"></div>
            </a>
        </li>
        <!-- menu title -->
        <li class="mt-10 mb-10 text-muted pl-4 font-medium menu-title"><?php echo e(trans('main_trans.Programname')); ?> </li>


        <!-- الامتحانات-->
        <li>
            <a href='/student/exams'>
                <i class="fas fa-book-open"></i>
                <span class="right-nav-text">الامتحانات</span>
            </a>
        </li>


        <!-- Settings-->
        <li>
            <a href='<?php echo e(url(app()->getLocale() . "/student/profile")); ?>'>
                <i class="fas fa-id-card-alt"></i>
                <span class="right-nav-text">الملف الشخصي</span>
            </a>
        </li>
    </ul>
</div>
<?php /**PATH C:\laragon\www\schools\resources\views/layouts/main-sidebar/student-main-sidebar.blade.php ENDPATH**/ ?>