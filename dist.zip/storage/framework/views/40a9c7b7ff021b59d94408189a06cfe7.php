<div>
    <div class="chatlist-header">
        <div class="title">
            Chat
        </div>
        <div class="img-container">
            <img src="https://picsum.photos/id/237/200/300" alt="">
        </div>
    </div>
    <div class="chatlist-body">
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="chatlist-item" wire:key='<?php echo e($conversation->id); ?>' wire:click="chatUserSelected(<?php echo e($conversation); ?>, <?php echo e($this->selectUserRelation($conversation)->id); ?>)">
                <div class="chatlist-img-container">
                    <img src='<?php echo e(asset("attachements/{$this->selectUserRelation($conversation)->profile}")); ?>' alt="">
                </div>
                <div class="chatlist-info">
                    <div class="top-row">
                        <div class="list-username"><?php echo e($this->selectUserRelation($conversation)->name); ?></div>
                        <span class="date"><?php echo e($conversation->messages->last()->created_at->shortAbsoluteDiffForHumans()); ?></span>
                    </div>
                    <div class="bottom-row">
                        <div class="message-body">
                            <?php echo e($conversation->messages->last()->body); ?>

                        </div>
                        <div class="unread-count">
                            <?php echo e($conversation->messages->where('read', 0)->count()); ?>

                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            You Have No Conversations
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\laragon\www\chat\resources\views/livewire/chat/chat-list.blade.php ENDPATH**/ ?>