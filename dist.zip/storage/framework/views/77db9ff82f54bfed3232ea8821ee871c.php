<div>
    <!--[if BLOCK]><![endif]--><?php if($selectedConversation): ?>
        <form action="" wire:submit.prevent="sendMessage">
            <div class="chatbox-footer">
                <div class="custsom-form-group">
                    <input type="text" class="control" placeholder="Send Message" wire:model="body">
                    <input type="submit" value="Send">
                </div>
            </div>
        </form>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\chat\resources\views/livewire/chat/send-message.blade.php ENDPATH**/ ?>