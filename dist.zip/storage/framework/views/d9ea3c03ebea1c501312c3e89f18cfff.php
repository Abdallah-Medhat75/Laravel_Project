<?php $__env->startSection('css'); ?>
    @toastr_css
<?php $__env->startSection('title'); ?>
    قائمة الاسئلة
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
<?php $__env->startSection('PageTitle'); ?>
قائمة الاسئلة : <span class="text-danger"><?php echo e($quizz->name); ?></span>
<?php $__env->stopSection(); ?>
<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-md-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <div class="col-xl-12 mb-30">
                        <?php if(session()->has('questions_deleted')): ?>
                            <div class="alert alert-success"><?php echo e(session()->get('questions_deleted')); ?></div>
                        <?php endif; ?>
                        <div class="card card-statistics h-100">
                            <div class="card-body">
                                <a href="<?php echo e(url(app()->getLocale() . "/teacher/questions/create/{$quizz->id}")); ?>" class="btn btn-success btn-sm" role="button" aria-pressed="true">اضافة سؤال جديد</a><br><br>
                                <div class="table-responsive">
                                    <table id="datatable" class="table  table-hover table-sm table-bordered p-0"
                                           data-page-length="50"
                                           style="text-align: center">
                                        <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">السؤال</th>
                                            <th scope="col">الاجابات</th>
                                            <th scope="col">الاجابة الصحيحة</th>
                                            <th scope="col">الدرجة</th>
                                            <th scope="col">اسم الاختبار</th>
                                            <th scope="col">العمليات</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($question->title); ?></td>
                                                <td><?php echo e($question->answers); ?></td>
                                                <td><?php echo e($question->right_answer); ?></td>
                                                <td><?php echo e($question->score); ?></td>
                                                <td><?php echo e($question->quiz->name); ?></td>
                                                <td>
                                                    <a href='<?php echo e(url(app()->getLocale() . "/teacher/questions/edit/{$question->id}")); ?>'
                                                       class="btn btn-info btn-sm" role="button" aria-pressed="true"><i
                                                            class="fa fa-edit"></i></a>
                                                    <button type="button" class="btn btn-danger btn-sm"
                                                            data-toggle="modal"
                                                            data-target="#delete_exam<?php echo e($question->id); ?>" title="حذف"><i
                                                            class="fa fa-trash"></i></button>
                                                </td>
                                            </tr>

                                        <?php echo $__env->make('pages.Teachers.dashboard.Questions.destroy', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    @toastr_js
    @toastr_render
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\schools\resources\views/pages/Teachers/dashboard/Questions/index.blade.php ENDPATH**/ ?>