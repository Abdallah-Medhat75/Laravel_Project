<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('my__parents', function (Blueprint $table) {
            $table->id();
            $table->string('email')->unique();
            $table->string('password');

            // Father information
            $table->string('Name_Father');
            $table->string('National_ID_Father');
            $table->string('Passport_ID_Father');
            $table->string('Phone_Father');
            $table->string('Job_Father');
            $table->bigInteger('Nationality_Father_id')->unsigned();
            $table->bigInteger('Blood_Type_Father_id')->unsigned();
            $table->bigInteger('Religion_Father_id')->unsigned();
            $table->string('Address_Father');

            //Mother information
            $table->string('Name_Mother');
            $table->string('National_ID_Mother');
            $table->string('Passport_ID_Mother');
            $table->string('Phone_Mother');
            $table->string('Job_Mother');
            $table->bigInteger('Nationality_Mother_id')->unsigned();
            $table->bigInteger('Blood_Type_Mother_id')->unsigned();
            $table->bigInteger('Religion_Mother_id')->unsigned();
            $table->string('Address_Mother');
            $table->timestamps();

            // Foreign Keys
            $table->foreign('Nationality_Father_id')->references('id')->on('nationalizes')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('Blood_Type_Father_id')->references('id')->on('type_bloods')->onDelete('cascade')->onUpdate('cascade');;
            $table->foreign('Religion_Father_id')->references('id')->on('religions')->onDelete('cascade')->onUpdate('cascade');;

            $table->foreign('Nationality_Mother_id')->references('id')->on('nationalizes')->onDelete('cascade')->onUpdate('cascade');;
            $table->foreign('Blood_Type_Mother_id')->references('id')->on('type_bloods')->onDelete('cascade')->onUpdate('cascade');;
            $table->foreign('Religion_Mother_id')->references('id')->on('religions')->onDelete('cascade')->onUpdate('cascade');;
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('my__parents');
    }
};
