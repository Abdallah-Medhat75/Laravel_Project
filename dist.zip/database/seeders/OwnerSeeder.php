<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

use App\Models\User;

class OwnerSeeder extends Seeder {
    public function run(): void {
        User::create([
            'name' => 'Abdallah Medhat',
            'email' => 'abdallah.medhata3@gmail.com',
            'profile' => 'abdallah_medhat.jpg',
            'password' => '12345678'
        ]);
        User::create([
            'name' => 'Yousef Atef',
            'email' => 'yousef.atef77@gmail.com',
            'profile' => 'yousef_atef.jpg',
            'password' => '12345678'
        ]);
    }
}
