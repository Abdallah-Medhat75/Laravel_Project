<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

use App\Models\User;

class UserTableSeeder extends Seeder
{
    public function run(): void
    {
        User::create([
            'name' => 'Abdallah Medhat',
            'email' => 'abdallah.medhata3@gmail.com',
            'password' => '12345678'
        ]);
        User::create([
            'name' => 'Yousef Atef',
            'email' => 'yousef.atef77@gmail.com',
            'password' => '12345678'
        ]);
        User::create([
            'name' => 'Yousef Osama',
            'email' => 'yousef.osama77@gmail.com',
            'password' => '12345678',
            'profile' => 'yousef_osama.jpg'
        ]);
        User::create([
            'name' => 'Ziad Rabee3',
            'email' => 'ziad.rabee377@gmail.com',
            'password' => '12345678'
        ]);
    }
}
