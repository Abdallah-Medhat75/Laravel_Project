<?php

use App\Http\Controllers\ChildrenController;
use Illuminate\Support\Facades\Route;

use Illuminate\Support\Facades\Auth;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;
use App\Models\Student;

Route::group(
    [
        'prefix' => LaravelLocalization::setLocale() . '/parent',
        'middleware' => ['localeSessionRedirect', 'localizationRedirect', 'localeViewPath', 'auth:parent']
    ], function () {
    Route::get('/dashboard', function () {
        $sons = Student::where('parent_id', Auth::user()->id)->get();
        return view('pages.parents.dashboard', compact('sons'));
    });
    Route::controller(ChildrenController::class)->group(function () {
        Route::get('/children', 'index');
        Route::get('/results/{id}', 'results');
        Route::get('/attendances', 'attendances');
        Route::post('/attendances/search', 'attendanceSearch');
        Route::get('/fees', 'fees');
        Route::get('/receipt/{id}', 'receiptStudent');
        Route::get('/profile', 'profile');
        Route::post('/profile/update/{id}', 'update');
    });
});
