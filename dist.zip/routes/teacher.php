<?php

use App\Http\Controllers\StudentExamController;
use App\Http\Controllers\TeacherController;
use App\Http\Controllers\TeacherDashboardController;
use App\Http\Controllers\TeacherProfileController;
use App\Http\Controllers\TeacherQuestionController;
use App\Http\Controllers\TeacherQuizzController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;

Route::group(
    [
        'prefix' => LaravelLocalization::setLocale() . '/teacher',
        'middleware' => ['localeSessionRedirect', 'localizationRedirect', 'localeViewPath', 'auth:teacher']
    ], function () {
    Route::get('/dashboard', [TeacherController::class, 'dashboard']);
    Route::controller(TeacherDashboardController::class)->group(function () {
        Route::get('/students', 'index');
        Route::get('/sections', 'sections');
        Route::post('/attendance', 'attendance')->name('attendance');
        Route::get('/attendance_report', 'attendanceReport');
        Route::post('/attendance_search', 'attendanceSearch')->name('attendance.search');
    });
    Route::controller(TeacherQuizzController::class)->group(function () {
        Route::get('/quizzes', 'index');
        Route::get('/quizzes/create', 'create');
        Route::get('/quizzes/show/{id}', 'show');
        Route::get('/quizzes/edit/{id}', 'edit');
        Route::post('/quizzes/destroy/{id}', 'destroy');
        Route::post('/quizzes/store', 'store');
        Route::post('/quizzes/update', 'update');
        Route::get('/quizzes/student_quizze/{id}', 'student_quizze');
        Route::post('/quizzes/repeat_quizze', 'repeat_quizze');
    });
    Route::controller(TeacherQuestionController::class)->group(function () {
        Route::get('/questions/create/{id}', 'create');
        Route::get('/questions/edit/{id}', 'edit');
        Route::post('/questions/store', 'store');
        Route::post('/questions/update/{id}', 'update');
        Route::post('/questions/destroy/{id}', 'destroy');
    });
    Route::controller(TeacherProfileController::class)->group(function () {
        Route::get('/profile', 'index');
        Route::post('/profile/update/{id}', 'update');
    });
});
