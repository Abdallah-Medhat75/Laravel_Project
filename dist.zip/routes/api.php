<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ConversationsDataController;

Route::controller(ConversationsDataController::class)->group(function () {
    Route::get('conversations/{authID}/{query}', 'index');
    Route::get('conversations/message/{sender_id}/{message_id}', 'retrieve');
});
