<?php

use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\ClassroomController;
use App\Http\Controllers\ExamController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\SectionController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Route;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;
use App\Http\Controllers\GradeController;
use App\Http\Controllers\GraduatedController;
use App\Http\Controllers\PromotionController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\TeacherController;
use App\Http\Controllers\FeeController;
use App\Http\Controllers\FeesInvoicesController;
use App\Http\Controllers\LibraryController;
use App\Http\Controllers\PaymentStudentController;
use App\Http\Controllers\ProcessingFeeController;
use App\Http\Controllers\QuestionController;
use App\Http\Controllers\QuizController;
use App\Http\Controllers\ReceiptStudentsController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\SubjectController;

// Auth::routes();

Route::get('/', [HomeController::class, 'index'])->name('selection');

Route::group(['namespace' => 'Auth'], function () {
    Route::get('/login/{type}', [LoginController::class, 'loginForm'])->middleware('guest')->name('login.show');
    Route::post('/login', [LoginController::class, 'login'])->name('login');
    Route::get('logout/{type}', [LoginController::class, 'logout'])->name('logout');
});

Route::group(
    [
        'prefix' => LaravelLocalization::setLocale(),
        'middleware' => ['localeSessionRedirect', 'localizationRedirect', 'localeViewPath', 'auth:web']
    ], function () {
    Route::get('/dashboard', [HomeController::class, 'dashboard'])->name('dashboard');
    Route::post('grades/update', [GradeController::class, 'update']);
    Route::post('grades/delete', [GradeController::class, 'destroy']);
    Route::resource('grades', GradeController::class);
    Route::resource('classrooms', ClassroomController::class);
    Route::controller(ClassroomController::class)->group(function () {
        Route::post('classrooms/update', 'update');
        Route::post('classrooms/delete', 'destroy');
    });
    Route::resource('sections', SectionController::class);
    Route::controller(SectionController::class)->group(function () {
        Route::post('sections/update', 'update');
        Route::post('sections/delete', 'destroy');
    });
    Route::get('/classes/{id}', [SectionController::class, 'getClasses']);
    Route::view('/add_parent', 'pages.parents.show_Form')->name('add_parent');
    Route::controller(TeacherController::class)->group(function () {
        Route::get('teachers', 'index')->name('Teachers.index');
        Route::get('teachers/create', 'create');
        Route::post('teachers/store', 'store');
        Route::get('teachers/edit/{id}', 'edit')->name('Teachers.edit');
        Route::post('teachers/update/', 'update')->name('Teachers.update');
        Route::post('teachers/delete', 'delete')->name('Teachers.delete');
    });
    Route::controller(StudentController::class)->group(function () {
        Route::get('students', 'index')->name('Students.index');
        Route::get('students/create', 'create')->name('Students.create');
        Route::post('students/store', 'store')->name('Students.store');
        Route::get('students/show/{id}', 'show')->name('Students.show');
        Route::get('students/edit/{id}', 'edit')->name('Students.edit');
        Route::post('students/destroy', 'destroy')->name('Students.destroy');
        Route::post('students/update', 'update')->name('Students.update');
        Route::post('Delete_attachment', 'Delete_attachment')->name('Delete_attachment');
        Route::get('Download_attachment/{studentsname}/{filename}', 'Download_attachment')->name('Download_attachment');
        Route::post('Upload_attachment', 'Upload_attachment')->name('Upload_attachment');
    });
    Route::controller(PromotionController::class)->group(function () {
        Route::get('promotion', 'index')->name('Promotion.index');
        Route::post('promotion/store', 'store')->name('Promotion.store');
        Route::get('promotion/create', 'create')->name('Promotion.create');
        Route::post('promotion/destroy', 'destroy')->name('Promotion.destroy');
    });
    Route::controller(GraduatedController::class)->group(function () {
        Route::get('graduated', 'index')->name('Graduated.index');
        Route::get('graduated/create', 'create')->name('Graduated.create');
        Route::post('graduated/store', 'store')->name('Graduated.store');
        Route::post('graduated/update', 'update')->name('Graduated.update');
        Route::post('graduated/destroy', 'destroy')->name('Graduated.destroy');
    });
    Route::controller(FeeController::class)->group(function () {
        Route::get('fees', 'index')->name('Fees.index');
        Route::get('fees/edit/{id}', 'edit')->name('Fees.edit');
        Route::get('fees/create', 'create')->name('Fees.create');
        Route::post('fees/store', 'store')->name('Fees.store');
        Route::post('fees/update', 'update')->name('Fees.update');
        Route::post('fees/destroy', 'destroy')->name('Fees.destroy');
    });
    Route::controller(FeesInvoicesController::class)->group(function () {
        Route::get('feesInvoices', 'index')->name('Fees_Invoices.index');
        Route::get('feesInvoices/edit/{id}', 'edit')->name('Fees_Invoices.edit');
        Route::get('feesInvoices/show/{id}', 'show')->name('Fees_Invoices.show');
        Route::post('feesInvoices/store', 'store')->name('Fees_Invoices.store');
        Route::post('feesInvoices/update', 'update')->name('Fees_Invoices.update');
        Route::post('feesInvoices/destroy', 'destroy')->name('Fees_Invoices.destroy');
    });
    Route::controller(ReceiptStudentsController::class)->group(function () {
        Route::get('receipt_students', 'index')->name('receipt_students.index');
        Route::get('receipt_students/show/{id}', 'show')->name('receipt_students.show');
        Route::get('receipt_students/edit/{id}', 'edit')->name('receipt_students.edit');
        Route::post('receipt_students/store', 'store')->name('receipt_students.store');
        Route::post('receipt_students/update', 'update')->name('receipt_students.update');
        Route::post('receipt_students/destroy', 'destroy')->name('receipt_students.destroy');
    });
    Route::controller(ProcessingFeeController::class)->group(function () {
        Route::get('processing_fee', 'index')->name('ProcessingFee.index');
        Route::get('processing_fee/edit/{id}', 'edit')->name('ProcessingFee.edit');
        Route::get('processing_fee/show/{id}', 'show')->name('ProcessingFee.show');
        Route::post('processing_fee/store', 'store')->name('ProcessingFee.store');
        Route::post('processing_fee/update', 'update')->name('ProcessingFee.update');
        Route::post('processing_fee/destroy', 'destroy')->name('ProcessingFee.destroy');
    });
    Route::controller(PaymentStudentController::class)->group(function () {
        Route::get('PaymentStudent', 'index')->name('Payment_students.index');
        Route::get('PaymentStudent/edit/{id}', 'edit')->name('Payment_students.edit');
        Route::get('PaymentStudent/show/{id}', 'show')->name('Payment_students.show');
        Route::post('PaymentStudent/store', 'store')->name('Payment_students.store');
        Route::post('PaymentStudent/update', 'update')->name('Payment_students.update');
        Route::post('PaymentStudent/destroy', 'destroy')->name('Payment_students.destroy');
    });
    Route::controller(AttendanceController::class)->group(function () {
        Route::get('Attendance', 'index')->name('Attendance.index');
        Route::get('Attendance/show/{id}', 'show')->name('Attendance.show');
        Route::post('Attendance/store', 'store')->name('Attendance.store');
        Route::post('Attendance/update', 'update');
        Route::post('Attendance/destroy', 'destroy');
    });
    Route::controller(SubjectController::class)->group(function () {
        Route::get('subjects', 'index')->name('subjects.index');
        Route::get('subjects/create', 'create')->name('subjects.create');
        Route::get('subjects/edit/{id}', 'edit')->name('subjects.edit');
        Route::post('subjects/store', 'store')->name('subjects.store');
        Route::post('subjects/update', 'update')->name('subjects.update');
        Route::post('subjects/destroy', 'destroy')->name('subjects.destroy');
    });
    Route::controller(QuizController::class)->group(function () {
        Route::get('quizzes', 'index')->name('Quizzes.index');
        Route::get('quizzes/create', 'create')->name('Quizzes.create');
        Route::get('quizzes/edit/{id}', 'edit')->name('Quizzes.edit');
        Route::post('quizzes/store', 'store')->name('Quizzes.store');
        Route::post('quizzes/update', 'update')->name('Quizzes.update');
        Route::post('quizzes/destroy', 'destroy')->name('Quizzes.destroy');
    });
    Route::controller(QuestionController::class)->group(function () {
        Route::get('questions', 'index')->name('questions.index');
        Route::get('questions/create', 'create')->name('questions.create');
        Route::get('questions/edit/{id}', 'edit')->name('questions.edit');
        Route::post('questions/store', 'store')->name('questions.store');
        Route::post('questions/update', 'update')->name('questions.update');
        Route::post('questions/destroy', 'destroy')->name('questions.destroy');
    });
    Route::controller(LibraryController::class)->group(function () {
        Route::get('library', 'index')->name('library.index');
        Route::get('library/create', 'create')->name('library.create');
        Route::get('library/edit/{id}', 'edit')->name('library.edit');
        Route::post('library/store', 'store')->name('library.store');
        Route::post('library/update', 'update')->name('library.update');
        Route::post('library/destroy', 'destroy')->name('library.destroy');
        Route::get('library/download/{filename}', 'download')->name('downloadAttachment');
    });
    Route::controller(SettingController::class)->group(function () {
        Route::get('settings', 'index')->name('settings.index');
        Route::post('settings/update', 'update')->name('settings.update');
    });
});
