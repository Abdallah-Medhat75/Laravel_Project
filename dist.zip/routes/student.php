<?php

use App\Http\Controllers\StudentExamController;
use App\Http\Controllers\StudentProfileController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;

Route::group(
    [
        'prefix' => LaravelLocalization::setLocale() . '/student',
        'middleware' => ['localeSessionRedirect', 'localizationRedirect', 'localeViewPath', 'auth:student']
    ], function () {
    Route::get('/dashboard', function () {
        return view('pages.Students.dashboard');
    });
    Route::controller(StudentExamController::class)->group(function () {
        Route::get('/exams', 'index');
        Route::get('/exams/show/{id}', 'show');
    });
    Route::controller(StudentProfileController::class)->group(function () {
        Route::get('/profile', 'index');
        Route::post('/profile/update/{id}', 'update');
    });
});
