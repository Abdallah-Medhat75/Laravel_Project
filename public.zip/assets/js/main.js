console.log('Before Working');
Echo.private('users.{{ auth()->user()->id }}').listen('.MessageRead', function (data) {
    console.log(`After Working ${data}`);
    window.Livewire.dispatch('refresh');
});
